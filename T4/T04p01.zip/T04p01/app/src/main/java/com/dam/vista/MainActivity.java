package com.dam.vista;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dam.adaptadores.AdaptadorImagenes;
import com.dam.dialogos.DlgConfirmacion;
import com.dam.logica.Datos;
import com.dam.logica.LogicaImagen;
import com.dam.modelo.Imagen;
import com.dam.tareas.DescargaImg;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
        implements DlgConfirmacion.DlgConfirmacionListener, DescargaImg.Listener, AdaptadorImagenes.ListItemClickListener {

    private EditText etUrl;
    private Button btAlta, btBaja;
    private Switch swEjecParalela;
    private RecyclerView rvImagenes;
    private ImageView ivImagen;
    private DescargaImg descargaImg;
    public static int tam;
    private List<DescargaImg> tareas = new ArrayList<>();
    private String mEstado;


    private AdaptadorImagenes mAdaptadorImagenes;


    private static final int IMAGEN_ALTA = 1;
    private static final int IMAGEN_BAJA = 2;
    private static final int DESCARGA_INICIADA = 3;
    private static final int DESCARGA_CANCELADA = 4;
    private static final int DESCARGA_FINALIZADA = 5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            // Restore value of members from saved state
            mEstado = savedInstanceState.getString(getString(R.string.app_name));
        } else {
            // Probably initialize members with default values for a new instance
            mEstado = getResources().getString(R.string.app_name);
        }
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // FindViewByIds
        etUrl = findViewById(R.id.etUrl);
        btAlta = findViewById(R.id.btAlta);
        btBaja = findViewById(R.id.btBaja);
        swEjecParalela = findViewById(R.id.swEjecParalela);
        rvImagenes = findViewById(R.id.rvImagenes);
        ivImagen = findViewById(R.id.ivImagen);

        // Inits
        Datos.getInstance().gettImagenes().clear();

        Imagen im1 = new Imagen("https://developer.android.com/training/basics/firstapp/images/screenshot-activity1.png");

        LogicaImagen.altaImagen(im1);
        Imagen im2 = new Imagen("https://developer.android.com/images/viewgroup_2x.png");
        LogicaImagen.altaImagen(im2);
        Imagen im3 = new Imagen("https://developer.android.com/images/training/basics/firstapp/building-ui-layout-editor-2x.png");
        LogicaImagen.altaImagen(im3);
        Imagen im4 = new Imagen("https://developer.android.com/training/basics/firstapp/images/constraint-example_2x.png");
        LogicaImagen.altaImagen(im4);
        Imagen im5 = new Imagen("https://developer.android.com/images/training/basics/firstapp/building-ui-constrained-top-left-2x.pngg");
        LogicaImagen.altaImagen(im5);
        Imagen im6 = new Imagen("https://developer.android.com/images/training/basics/firstapp/building-ui-constrained-baseline-2x.png");
        LogicaImagen.altaImagen(im6);
        Imagen im7 = new Imagen("https://developer.android.com/training/basics/firstapp/images/add-string_2x.png");
        LogicaImagen.altaImagen(im7);
        Imagen im8 = new Imagen("https://developer.android.com/images/training/basics/firstapp/building-ui-horizontal-chain-2x.png");
        LogicaImagen.altaImagen(im8);

        rvImagenes.setHasFixedSize(true);
        rvImagenes.setLayoutManager(new LinearLayoutManager(this));
        rvImagenes.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        mAdaptadorImagenes = new AdaptadorImagenes(this, Datos.getInstance().gettImagenes());
        rvImagenes.setAdapter(mAdaptadorImagenes);

        // Listeners
        btAlta.setOnClickListener(btAlta_OnClickListener);
        btBaja.setOnClickListener(btBaja_OnClickListener);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {

            case R.id.menuIniciarDescargas:
                tam = Datos.getInstance().gettImagenes().size();
                for (int i = 0; i <tareas.size() ; i++) {
                    if(!tareas.get(i).isCancelled())
                        tareas.get(0).cancel(true);
                    tareas.clear();

                }

                for (Imagen img : Datos.getInstance().gettImagenes()) {
                    img.setEstado(Imagen.ESTADO.INI);
                    actualizarRV(3);
                    descargaImg = new DescargaImg(this,img.getUrl());
                    tareas.add(descargaImg);
                }
                for(DescargaImg t:tareas){
                    if (swEjecParalela.isChecked())  //pararell download
                        t.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    else //sequentally download

                        t.execute();

                }
                return true;

            case R.id.menuCancelarDescargas:

                if (descargaImg != null) {
                    descargaImg.cancel(true);
                    Snackbar.make(findViewById(android.R.id.content), R.string.msg_DescargasCanceladas, Snackbar.LENGTH_SHORT).show();
                }
                return true;

            case R.id.menuSalir:
                mostrarDlgSalir();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void mostrarDlgSalir() {
        DlgConfirmacion dc = new DlgConfirmacion();
        dc.setTitulo(R.string.app_name);
        dc.setMensaje(R.string.msg_Salir);
        dc.setCancelable(false);
        dc.show(getSupportFragmentManager(), "tagSalir");
    }

    @Override
    public void onDlgConfirmacionPositiveClick(DialogFragment dialog) {
        switch (dialog.getTag()) {
            case "tagSalir":
                finish();
                break;
        }
    }

    @Override
    public void onDlgConfirmacionNegativeClick(DialogFragment dialog) {

    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        mostrarDlgSalir();
    }

    private View.OnClickListener btAlta_OnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            // Ocultar teclado
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
            if (!checkUrl())
                return;
            Imagen im = new Imagen(etUrl.getText().toString());
            im.setUrl(im.getUrl());
            im.setEstado(Imagen.ESTADO.CREADA);
            if (LogicaImagen.altaImagen(im)) {
                Snackbar.make(findViewById(android.R.id.content), R.string.msg_AltaImagenOK, Snackbar.LENGTH_SHORT).show();
                actualizarRV(1);
                return;
            }
            etUrl.setText("");
            Snackbar.make(findViewById(android.R.id.content), R.string.msg_AltaImagenKO, Snackbar.LENGTH_SHORT).show();
        }
    };

    private boolean checkUrl() {
        if (!etUrl.getText().toString().startsWith("https://")) {
            Snackbar.make(findViewById(android.R.id.content), R.string.urlKO, Snackbar.LENGTH_SHORT).show();
            return false;
        }
        return true;

    }

    private View.OnClickListener btBaja_OnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            // Ocultar teclado
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
            Imagen i = Datos.getInstance().gettImagenes().get(mAdaptadorImagenes.getItemPos());
            if (LogicaImagen.bajaImagen(i)) {
                Snackbar.make(findViewById(android.R.id.content), R.string.msg_BajaImagenOK, Snackbar.LENGTH_SHORT).show();
                actualizarRV(2);
                return;
            }
            Snackbar.make(findViewById(android.R.id.content), R.string.msg_BajaImagenKO, Snackbar.LENGTH_SHORT).show();
        }
    };

    private void actualizarRV(int tipoOP) {
        // Actualiza RV tras operación de alta, baja, inicio, cancelación o finalización
        switch (tipoOP) {
            case IMAGEN_ALTA:
                mAdaptadorImagenes.notifyItemInserted(mAdaptadorImagenes.getItemPos());
                rvImagenes.smoothScrollToPosition(mAdaptadorImagenes.getItemCount() - 1);
                break;
            case IMAGEN_BAJA:
                mAdaptadorImagenes.notifyItemRemoved(mAdaptadorImagenes.getItemPos());
                mAdaptadorImagenes.setItemPos(-1);
                break;
            case DESCARGA_INICIADA:
                for (int i = 0; i < mAdaptadorImagenes.getItemCount() ; i++) {
                    mAdaptadorImagenes.notifyItemChanged(mAdaptadorImagenes.getItemPos());
                    rvImagenes.smoothScrollToPosition(i);
                }

                break;
            case DESCARGA_CANCELADA:
            case DESCARGA_FINALIZADA:

                break;

        }
        mAdaptadorImagenes.notifyDataSetChanged();

    }


    @Override
    public void onPreexecute(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onImgDescargada(String url, Bitmap img) {
        int p=0;
        for (Imagen i : Datos.getInstance().gettImagenes()) {
            if (i.getUrl().equalsIgnoreCase(url)) {
                i.setBitmap(img);
                i.setEstado(Imagen.ESTADO.FIN);
                mAdaptadorImagenes.setItemPos(p);
                p++;
                actualizarRV(5);

            }
        }
    }

    @Override
    public void onImgError(String url) {
        for (Imagen i : Datos.getInstance().gettImagenes()) {
            if (i.getUrl().equalsIgnoreCase(url)) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.yl7329xmxin31);
                i.setEstado(Imagen.ESTADO.CANCELADA);
                i.setBitmap(bitmap);
                actualizarRV(4);
            }
        }
    }

    @Override
    public void onCancel() {
        Snackbar.make(findViewById(android.R.id.content), R.string.msg_DescargasCanceladas, Snackbar.LENGTH_SHORT).show();
        for (int i = 0; i < tareas.size() - 1; i++)
            tareas.get(i).cancel(true);
    }

    @Override
    public void onFinalize() {
        Snackbar.make(findViewById(android.R.id.content), getString(R.string.msg_DescargasFinalizadas), Snackbar.LENGTH_SHORT).show();
        int ok = 0, ko = 0;
        for (int i = 0; i < Datos.getInstance().gettImagenes().size(); i++) {
            if (Datos.getInstance().gettImagenes().get(i).getEstado().equals(Imagen.ESTADO.FIN))
                ok++;
            else
                ko++;
            Snackbar.make(findViewById(android.R.id.content), "Imágenes descargadas: " + ok + " Imágenes no descargadas: " + ko, Snackbar.LENGTH_LONG).show();


        }
    }

    @Override
    public void onItemClick(int position) {
        ivImagen.setImageBitmap(Datos.getInstance().gettImagenes().get(position).getBitmap());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        for (int i = 0; i < tareas.size() - 1; i++)
            tareas.get(i).cancel(true);
        tareas.clear();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        for (int i = 0; i < tareas.size() - 1; i++)
            tareas.get(i).cancel(true);
        tareas.clear();
        Toast.makeText(this,getString(R.string.msg_Info),Toast.LENGTH_SHORT).show();

    }
}


