package com.dam.adaptadores;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dam.modelo.Imagen;
import com.dam.vista.R;

import java.util.List;

public class AdaptadorImagenes extends RecyclerView.Adapter<AdaptadorImagenes.ImagenVH> {

    private List<Imagen> mDatos;
    private int mItemPos;
    private Context mContext;
    private final ListItemClickListener mOnClickListener;

    public AdaptadorImagenes(Context context, List<Imagen> datos) {
        mContext = context;
        mDatos = datos;
        mItemPos = -1;
        mOnClickListener = (ListItemClickListener) context;
    }

    public int getItemPos() {
        return mItemPos;
    }

    public void setItemPos(int itemPos) {
        mItemPos = itemPos;
    }

    @NonNull
    @Override
    public ImagenVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.content_rv_imagenes, parent, false);
        return new ImagenVH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ImagenVH holder, int position) {
        holder.setItem(mDatos.get(position));
        holder.itemView.setBackgroundColor((mItemPos == position)
                ? holder.itemView.getContext().getResources().getColor(R.color.colorAccent)
                : Color.TRANSPARENT);
    }

    @Override
    public int getItemCount() {
        return mDatos.size();
    }

    public class ImagenVH extends RecyclerView.ViewHolder
            implements View.OnClickListener,View.OnLongClickListener {

        private TextView tvUrl;
        private ImageView ivEstado;

        public ImagenVH(@NonNull View itemView) {
            super(itemView);
            tvUrl = itemView.findViewById(R.id.tvUrl);
            ivEstado = itemView.findViewById(R.id.ivEstado);
            itemView.setOnClickListener(this);
            itemView.setOnLongClickListener(this);
        }

        private void setItem(Imagen img) {
            tvUrl.setText(img.getUrl());
            switch (img.getEstado()) {
                case CREADA:
                    ivEstado.setImageDrawable(mContext.getResources().getDrawable(android.R.drawable.ic_media_pause));
                    break;
                case INI:
                    ivEstado.setImageDrawable(mContext.getResources().getDrawable(android.R.drawable.ic_media_play));
                    break;
                case FIN:
                    ivEstado.setImageDrawable(mContext.getResources().getDrawable(android.R.drawable.ic_menu_view));
                    break;
                case CANCELADA:
                    ivEstado.setImageDrawable(mContext.getResources().getDrawable(android.R.drawable.ic_delete));
                    break;
            }

        }

        @Override
        public void onClick(View v) {
            int pos = getLayoutPosition();
            notifyItemChanged(mItemPos);
            mItemPos = (mItemPos == pos) ? -1 : pos;
            mOnClickListener.onItemClick(pos);
            notifyItemChanged(mItemPos);
        }

        @Override
        public boolean onLongClick(View v) {
                Toast.makeText(v.getContext(), "long click", Toast.LENGTH_SHORT).show();
            return false;

        }
    }
    //interface for comunicate with mainActivity
    public interface ListItemClickListener {
            void onItemClick(int position);
        }
}
