package com.dam.tareas;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.util.Log;

import com.dam.modelo.Imagen;
import com.dam.vista.MainActivity;
import com.dam.vista.R;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class DescargaImg extends AsyncTask<Void, Void, Bitmap> {

    private Listener mListener;
    private InputStream inputStream;
    private HttpsURLConnection httpsURLConnection;
    private Bitmap imgDescargada;
    private String stringImg;
    private URL urlImg;
    private Context mContext;
    private NetworkInfo networkInfo;
    private ConnectivityManager connectivityManager;
    private String url;

    public DescargaImg(Context context, String url) {
        this.mListener = (Listener) context;
        this.mContext = context;
        this.url = url;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        ConnectivityManager connectivityManager = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if (networkInfo == null || !networkInfo.isConnected() ||
                    (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                            && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
                mListener.onPreexecute(mContext.getString(R.string.internetKO));
                cancel(true);
            } else {
                if (mListener != null)
                    mListener.onPreexecute(mContext.getString(R.string.downstart) + " : " + url);
            }
        } else {
            mListener.onPreexecute(mContext.getString(R.string.internetKO));
            cancel(true);
        }
    }


    @Override
    protected Bitmap doInBackground(Void... voids) {

        //cath the first parameter into uslImg local variable
        stringImg = url;
        //transform this sting in URL type(instance a new URL object with string as parameter)
        try {
            urlImg = new URL(stringImg);
            //try set a  connection with this url
            httpsURLConnection = (HttpsURLConnection) urlImg.openConnection();
            // Timeout for reading InputStream arbitrarily set to 3000ms.
            httpsURLConnection.setReadTimeout(3000);
            // Timeout for connection.connect() arbitrarily set to 3000ms.
            httpsURLConnection.setConnectTimeout(3000);
            // For this use case, set HTTP method to GET.
            httpsURLConnection.setRequestMethod("GET");
            // Already true by default but setting just in case; needs to be true since this request
            // is carrying an input (response) body.
            httpsURLConnection.setDoInput(true);
            // Open communications link (network traffic occurs here).
            httpsURLConnection.connect();
            inputStream = new URL(stringImg).openStream();
            imgDescargada = BitmapFactory.decodeStream(httpsURLConnection.getInputStream());
            return imgDescargada;

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            //close the current connection
            if (httpsURLConnection != null)
                httpsURLConnection.disconnect();
        }
        if (isCancelled())
            if (mListener != null)
                mListener.onCancel();
        return null;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        MainActivity.tam--;
        if (bitmap == null)
            mListener.onImgError(stringImg);
        else
            mListener.onImgDescargada(stringImg, imgDescargada);
        if (MainActivity.tam == 0)
            mListener.onFinalize();
    }


    //interface for communication with main activity
    public interface Listener {
        void onPreexecute(String msg);

        void onImgDescargada(String url, Bitmap img);

        void onImgError(String url);

        void onCancel();

        void onFinalize();
    }
}
