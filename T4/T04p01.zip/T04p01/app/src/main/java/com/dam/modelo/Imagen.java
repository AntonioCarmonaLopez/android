package com.dam.modelo;

import android.graphics.Bitmap;

public class Imagen {

    /* Atributos **********************************************************************************/
    private String url;         // PK
    private Bitmap bitmap;
    private ESTADO estado;

    public enum ESTADO {CREADA, INI, FIN, CANCELADA}

    /* Constructores ******************************************************************************/

    public Imagen(String url) {
        this.url = url;
        this.bitmap = null;
        this.estado = ESTADO.CREADA;
    }

    /* Getters & Setters **************************************************************************/

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public ESTADO getEstado() {
        return estado;
    }

    public void setEstado(ESTADO estado) {
        this.estado = estado;
    }

}
