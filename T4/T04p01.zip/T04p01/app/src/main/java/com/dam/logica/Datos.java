package com.dam.logica;

import com.dam.modelo.Imagen;

import java.util.ArrayList;
import java.util.List;

public class Datos {

    /* Singleton **********************************************************************************/

    private static Datos datos;

    private List<Imagen> tImagenes;

    /* Constructores ******************************************************************************/

    private Datos() {
        tImagenes = new ArrayList<>();
    }

    /* Métodos ************************************************************************************/

    public static Datos getInstance() {
        if (datos == null)
            datos = new Datos();
        return datos;
    }

    public List<Imagen> gettImagenes() {
        return tImagenes;
    }

}
