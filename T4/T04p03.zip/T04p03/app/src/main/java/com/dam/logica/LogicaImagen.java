package com.dam.logica;

import com.dam.modelo.Imagen;

public class LogicaImagen {

    /* Métodos ************************************************************************************/

    public static Imagen getImagen(String url) {
        for (Imagen im : Datos.getInstance().gettImagenes()) {
            if (im.getUrl().equals(url)) {
                return im;
            }
        }
        return null;
    }

    public static boolean existeImagen(Imagen im) {
        for (Imagen imagen : Datos.getInstance().gettImagenes()) {
            if (imagen.getUrl().equals(im.getUrl())) {
                return true;
            }
        }
        return false;
    }

    public static boolean altaImagen(Imagen im) {
        if (existeImagen(im)) {
            return false;
        }
        return Datos.getInstance().gettImagenes().add(im);
    }

    public static boolean bajaImagen(Imagen im) {
        if (!existeImagen(im)) {
            return false;
        }
        for (Imagen imagen : Datos.getInstance().gettImagenes()) {
            if (imagen.getUrl().equals(im.getUrl())) {
                return Datos.getInstance().gettImagenes().remove(imagen);
            }
        }
        return false;
    }

}
