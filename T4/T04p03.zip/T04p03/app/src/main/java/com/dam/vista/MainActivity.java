package com.dam.vista;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.DialogFragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import com.dam.adaptadores.AdaptadorImagenes;
import com.dam.dialogos.DlgConfirmacion;
import com.dam.logica.Datos;
import com.dam.logica.LogicaImagen;
import com.dam.modelo.Imagen;
import com.dam.tareas.AnalizaUrl;
import com.dam.tareas.DescargaImagenesService;
import com.dam.tareas.Worker;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity
        implements DlgConfirmacion.DlgConfirmacionListener, AdaptadorImagenes.ListItemClickListener {

    private EditText etUrl;
    private Button btAnalizar;
    private RecyclerView rvImagenes;
    private ImageView ivImagen;

    private AdaptadorImagenes mAdaptadorImagenes;

    private static final int IMAGENES_ALTA = 1;
    private static final int DESCARGA_INICIADA = 2;
    private static final int DESCARGA_REINICIADA = 3;
    private static final int DESCARGA_CANCELADA = 4;
    private static final int DESCARGA_FINALIZADA = 5;
    private Intent i;
    private String url;
    private Receptor mReceptor;
    private AnalizaUrl analizaUrl;
    private boolean mServicioActivo;
    private boolean mWorkActivo;
    private byte[] byteArray;
    private Imagen img;
    private Constraints mConstraints;
    private final int DELAY=10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // FindViewByIds
        etUrl = findViewById(R.id.etUrl);
        btAnalizar = findViewById(R.id.btAnalizar);
        rvImagenes = findViewById(R.id.rvImagenes);
        ivImagen = findViewById(R.id.ivImagen);

        // Inits
        Datos.getInstance().gettImagenes().clear();


        url = "https://developer.android.com/studio";
        etUrl.setText(url);

        rvImagenes.setHasFixedSize(true);
        rvImagenes.setLayoutManager(new LinearLayoutManager(this));

        rvImagenes.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        mAdaptadorImagenes = new AdaptadorImagenes(this, Datos.getInstance().gettImagenes());
        rvImagenes.setAdapter(mAdaptadorImagenes);
        mReceptor = new Receptor();
        //register  mReceptor & actions
        IntentFilter inf = new IntentFilter();
        inf.addAction(AnalizaUrl.BROADCAST_CONN);
        inf.addAction(AnalizaUrl.BROADCAST_INI);
        inf.addAction(AnalizaUrl.BROADCAST_SEND);
        inf.addAction(AnalizaUrl.BROADCAST_END);
        inf.addAction(DescargaImagenesService.DESCARGAIMAGEN_INI_IMAGEN_ACTION);
        inf.addAction(DescargaImagenesService.DESCARGAIMAGEN_FIN_IMAGEN_ACTION);
        inf.addAction(Worker.DESCARGAIMAGEN_FIN_IMAGEN_ACTION);
        inf.addAction(DescargaImagenesService.DESCARGAIMAGEN_ERROR_IMAGEN_ACTION);
        inf.addAction(Worker.DESCARGAIMAGEN_ERROR_IMAGEN_ACTION);
        inf.addAction(DescargaImagenesService.DESCARGAIMAGEN_FIN_ACTION);
        inf.addAction(DescargaImagenesService.DESCARGAIMAGEN_CANCEL_ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(mReceptor, inf);
        // Listeners
        btAnalizar.setOnClickListener(btAnalizar_OnClickListener);

    }

    @Override
    public void onItemClick(int position) {
        ivImagen.setImageBitmap(Datos.getInstance().gettImagenes().get(position).getBitmap());
    }

    private class Receptor extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case AnalizaUrl.BROADCAST_CONN:
                    String conn = intent.getStringExtra("conn");
                    Snackbar.make(findViewById(android.R.id.content), conn, Snackbar.LENGTH_SHORT).show();
                    break;
                case AnalizaUrl.BROADCAST_INI:
                    String ini = intent.getStringExtra("start");
                    Snackbar.make(findViewById(android.R.id.content), ini, Snackbar.LENGTH_SHORT).show();
                    break;
                case AnalizaUrl.BROADCAST_SEND:
                    ArrayList<String> urls = intent.getExtras().getStringArrayList("result");
                    for (String url : urls) {
                        img = new Imagen(url);
                        if (LogicaImagen.altaImagen(img))
                            actualizarRV(1);
                    }
                    break;
                case AnalizaUrl.BROADCAST_END:
                    String end = intent.getStringExtra("end");
                    Snackbar.make(findViewById(android.R.id.content), end, Snackbar.LENGTH_SHORT).show();
                    break;
                case AnalizaUrl.BROADCAST_ERROR:
                    String error = intent.getStringExtra("error");
                    Snackbar.make(findViewById(android.R.id.content), error, Snackbar.LENGTH_SHORT).show();
                    break;
                case DescargaImagenesService.DESCARGAIMAGEN_INI_IMAGEN_ACTION:
                    for (Imagen i : Datos.getInstance().gettImagenes()) {
                        if (i.getUrl().equals((intent.getStringExtra("url")))) {
                            i.setEstado(Imagen.ESTADO.INI);
                            Snackbar.make(findViewById(android.R.id.content), "Descarga: " + i.getUrl() + " iniciada", Snackbar.LENGTH_SHORT).show();
                        }
                    }
                    //Snackbar.make(findViewById(android.R.id.content), "Descarga: " + url + " iniciada", Snackbar.LENGTH_SHORT).show();
                    actualizarRV(2);
                    break;
                case DescargaImagenesService.DESCARGAIMAGEN_FIN_IMAGEN_ACTION:
                case Worker.DESCARGAIMAGEN_FIN_IMAGEN_ACTION:
                    for (Imagen i : Datos.getInstance().gettImagenes()) {
                        if (i.getUrl().equals((intent.getStringExtra("url")))) {
                            i.setEstado(Imagen.ESTADO.FIN);
                            byteArray = intent.getByteArrayExtra("img");
                            Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                            i.setBitmap(bitmap);
                            Snackbar.make(findViewById(android.R.id.content), "Descarga: " + i.getUrl() + " finalizada", Snackbar.LENGTH_SHORT).show();
                        }
                    }
                    actualizarRV(5);
                    break;
                case DescargaImagenesService.DESCARGAIMAGEN_ERROR_IMAGEN_ACTION:
                case Worker.DESCARGAIMAGEN_ERROR_IMAGEN_ACTION:
                    for (Imagen i : Datos.getInstance().gettImagenes()) {
                        if (i.getUrl().equals((intent.getStringExtra("url")))) {
                            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.error);
                            i.setEstado(Imagen.ESTADO.CANCELADA);
                            i.setBitmap(bitmap);
                            Snackbar.make(findViewById(android.R.id.content), "Descarga: " + i.getUrl() + " cancelada", Snackbar.LENGTH_SHORT).show();
                        }
                    }
                    actualizarRV(4);
                    break;
                case DescargaImagenesService.DESCARGAIMAGEN_CANCEL_ACTION:
                    Toast.makeText(MainActivity.this, getString(R.string.msg_DescargasCanceladas), Toast.LENGTH_SHORT).show();
                    break;
                case DescargaImagenesService.DESCARGAIMAGEN_FIN_ACTION:
                case Worker.DESCARGAIMAGEN_FIN_ACTION:
                    Toast.makeText(MainActivity.this, getString(R.string.msg_DescargasFinalizadas), Toast.LENGTH_SHORT).show();
                    mServicioActivo = false;
                    mWorkActivo = false;
                    break;
            }

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {

            case R.id.iniIsrv:
                iniciarDescargasIsrv();
                Snackbar.make(findViewById(android.R.id.content), R.string.msg_DescargasIniciadas, Snackbar.LENGTH_SHORT).show();
                return true;
            case R.id.iniWork:
                Snackbar.make(findViewById(android.R.id.content), getString(R.string.msg_DescargasIniciadas)+" "+DELAY+" segundos", Snackbar.LENGTH_SHORT).show();
                iniciarDescargasWork();
                return true;
            case R.id.menuCancelarDescargas:
                swithOff();
                return true;

            case R.id.menuSalir:
                mostrarDlgSalir();
                return true;
        }
        return super.

                onOptionsItemSelected(item);

    }


    private void iniciarDescargasIsrv() {
        if (!mServicioActivo) {
            i = new Intent(this, DescargaImagenesService.class);
            mServicioActivo = true;
            for (Imagen img : Datos.getInstance().gettImagenes()) {
                i.putExtra("url", img.getUrl());
                i.putExtra("tam",Integer.parseInt(String.valueOf(Datos.getInstance().gettImagenes().size())));
                startService(i);
            }
        }
    }

    private void iniciarDescargasWork() {
        if (!mWorkActivo) {
            mWorkActivo = true;
            Data i = null;
            String[] urls = new String[Datos.getInstance().gettImagenes().size()];
            //make StringBuider with urls for pass to worker
            int j = 0;
            mConstraints = new Constraints.Builder()
                    .setRequiresStorageNotLow(true)
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build();
            for (Imagen im : Datos.getInstance().gettImagenes())
                urls[j++] = im.getUrl();

            //Log.i("w",urls[1]);
            i = new Data.Builder()
                    .putStringArray("urls", urls)
                    .build();

            OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(Worker.class)
                    .setConstraints(mConstraints)
                    .setInitialDelay(DELAY, TimeUnit.SECONDS)
                    .addTag("myworker")
                    .setInputData(i)
                    .build();
            WorkManager.getInstance(getApplicationContext())
                    .enqueue(request);
        }
    }

    private void mostrarDlgSalir() {
        DlgConfirmacion dc = new DlgConfirmacion();
        dc.setTitulo(R.string.app_name);
        dc.setMensaje(R.string.msg_Salir);
        dc.setCancelable(false);
        dc.show(getSupportFragmentManager(), "");
    }

    @Override
    public void onDlgConfirmacionPositiveClick(DialogFragment dialog) {
        finish();
    }

    @Override
    public void onDlgConfirmacionNegativeClick(DialogFragment dialog) {
        ;
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        mostrarDlgSalir();
    }

    private View.OnClickListener btAnalizar_OnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            // Ocultar teclado
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
            analizaUrl = new AnalizaUrl(getApplicationContext(), url);
            if (analizaUrl.isCancelled()) {
                analizaUrl.cancel(true);
                Toast.makeText(MainActivity.this, R.string.msg_AnalisisUrlReiniciado, Toast.LENGTH_SHORT).show();
                Datos.getInstance().gettImagenes().clear();
                actualizarRV(4);
            } else
                Toast.makeText(MainActivity.this, R.string.msg_AnalisisUrlReiniciado, Toast.LENGTH_SHORT).show();
            analizaUrl.execute();
        }
    };

    private void actualizarRV(int tipoOP, String... url) {
        // Actualiza RV tras operación de alta, inicio, cancelación o finalización
        switch (tipoOP) {
            case IMAGENES_ALTA:
                mAdaptadorImagenes.notifyItemInserted(mAdaptadorImagenes.getItemPos());
                break;
            case DESCARGA_INICIADA:
            case DESCARGA_REINICIADA:
            case DESCARGA_CANCELADA:
            case DESCARGA_FINALIZADA:
                mAdaptadorImagenes.notifyDataSetChanged();
        }
    }

    /*@Override
    protected void onDestroy() {
        super.onDestroy();
        swithOff();
    }*/

    private void swithOff() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mReceptor);

        if (mServicioActivo) {
            i = new Intent(this, DescargaImagenesService.class);
            stopService(i);
            mServicioActivo = false;
        }
        if(mWorkActivo)
            WorkManager.getInstance(this).cancelAllWorkByTag("myworker");

        if (analizaUrl != null)
            analizaUrl.cancel(true);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Toast.makeText(getApplicationContext(), R.string.apagar, Toast.LENGTH_SHORT).show();
    }

}
