package com.dam.tareas;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.work.Data;
import androidx.work.WorkerParameters;

import com.dam.vista.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class Worker extends androidx.work.Worker {

    private HttpsURLConnection httpsURLConnection;
    private Bitmap imgDescargada;
    private InputStream inputStream;

    private static final String NOTIFY_CHANNEL_ID = "my_channel";
    private static final int NOTIFY_ID = 1;


    public static final String DESCARGAIMAGEN_FIN_IMAGEN_ACTION = "com.T04p03.sending_down_fin_img";
    public static final String DESCARGAIMAGEN_ERROR_IMAGEN_ACTION = "com.T04p03.sending_down_error_img";
    public static final String DESCARGAIMAGEN_FIN_ACTION = "com.T04p03.sending_fin_img";

    private byte[] byteArray;
    private Intent intent;
    private boolean mFin;

    private NotificationCompat.Builder mBuilder;
    private NotificationManagerCompat mManager;

    public Worker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
        // Creamos la notificación
        mBuilder = new NotificationCompat.Builder(getApplicationContext(), NOTIFY_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_not)
                .setContentTitle(getApplicationContext().getResources().getString(R.string.msg_DescargasIniciadas))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(PendingIntent.getActivity(getApplicationContext(), 0, new Intent(), 0))
                .setAutoCancel(true);
        mManager = NotificationManagerCompat.from(getApplicationContext());

    }

    @NonNull
    @Override
    public Result doWork() {
        // Notificación de inicio
        mBuilder.setContentText(getApplicationContext().getResources().getString(R.string.msg_DescargasIniciadas));
        mBuilder.setProgress(0, 0, false);
        mManager.notify(NOTIFY_ID, mBuilder.build());

        String[] urls = getInputData().getStringArray("urls");

        for (int i = 0; i < urls.length - 1; i++) {
            //transform this sting in URL type(instance a new URL object with string as parameter)
            try {

                URL urlImg = new URL(urls[i]);
                //try set a  connection with this url
                httpsURLConnection = (HttpsURLConnection) urlImg.openConnection();
                // Timeout for reading InputStream arbitrarily set to 3000ms.
                httpsURLConnection.setReadTimeout(3000);
                // Timeout for connection.connect() arbitrarily set to 3000ms.
                httpsURLConnection.setConnectTimeout(3000);
                // For this use case, set HTTP method to GET.
                httpsURLConnection.setRequestMethod("GET");
                // Already true by default but setting just in case; needs to be true since this request
                // is carrying an input (response) body.
                httpsURLConnection.setDoInput(true);
                // Open communications link (network traffic occurs here).
                httpsURLConnection.connect();
                inputStream = new URL(urls[i]).openStream();
                imgDescargada = BitmapFactory.decodeStream(httpsURLConnection.getInputStream());
                byteArray=convertirBitmap();
                intent = new Intent(DESCARGAIMAGEN_FIN_IMAGEN_ACTION);
                intent.putExtra("img",byteArray);
                intent.putExtra("url",urls[i]);
                LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);
                // Notificación de progreso
                mBuilder.setContentText(getApplicationContext().getResources().getString(R.string.msg_DescargasIniciadas));
                mBuilder.setProgress(urls.length, urls.length - i, false);
                mBuilder.setNumber(i);
                mManager.notify(NOTIFY_ID, mBuilder.build());
            } catch (IOException e) {
                intent=new Intent(DESCARGAIMAGEN_ERROR_IMAGEN_ACTION);
                intent.putExtra("url",urls[i]);
                LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);
                Result.failure();

            } finally {
                if(mFin) {
                    // Notificación de cancelación
                    mBuilder.setContentText(getApplicationContext().getResources().getString(R.string.msg_DescargasCanceladas));
                    mManager.notify(NOTIFY_ID, mBuilder.build());
                } else {
                    // Notificación de fin
                     mBuilder.setContentText(getApplicationContext().getResources().getString(R.string.msg_DescargasFinalizadas));
                                    mBuilder.setProgress(0, 0, false);
                                    mManager.notify(NOTIFY_ID, mBuilder.build());
                }

                //close the current connection
                if (httpsURLConnection != null)
                    httpsURLConnection.disconnect();
            }
        }
        return Result.success();
    }

    private byte[] convertirBitmap() {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        imgDescargada.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;

    }

    @Override
    public void onStopped() {
        super.onStopped();
        intent=new Intent(DESCARGAIMAGEN_FIN_ACTION);
        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);
        mFin=true;
    }
}
