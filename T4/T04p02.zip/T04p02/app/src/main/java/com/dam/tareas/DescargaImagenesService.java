package com.dam.tareas;

import android.app.IntentService;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.annotation.Nullable;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class DescargaImagenesService extends IntentService {

    private HttpsURLConnection httpsURLConnection;
    private Bitmap imgDescargada;
    private InputStream inputStream;

    public static final String DESCARGAIMAGEN_FIN_ACTION = "com.T04p02.sending_down_fin";
    public static final String DESCARGAIMAGEN_INI_IMAGEN_ACTION = "com.T04p02.sending_down_ini_img";
    public static final String DESCARGAIMAGEN_FIN_IMAGEN_ACTION = "com.T04p02.sending_down_fin_img";
    public static final String DESCARGAIMAGEN_ERROR_IMAGEN_ACTION = "com.T04p02.sending_down_error_img";
    public static final String DESCARGAIMAGEN_CANCEL_ACTION = "com.T04p02.sending_down_cancel";

    private boolean mFin;
    private String stringImg;
    private byte[] byteArray;
    private Intent i;

    public DescargaImagenesService() {
        super("DescargaImagenesService");
    }

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        i = new Intent(DESCARGAIMAGEN_INI_IMAGEN_ACTION);
        i.putExtra("url", stringImg);
        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

        //transform this sting in URL type(instance a new URL object with string as parameter)
        try {
            stringImg = intent.getStringExtra("url");
            URL urlImg = new URL(stringImg);
            //try set a  connection with this url
            httpsURLConnection = (HttpsURLConnection) urlImg.openConnection();
            // Timeout for reading InputStream arbitrarily set to 3000ms.
            httpsURLConnection.setReadTimeout(3000);
            // Timeout for connection.connect() arbitrarily set to 3000ms.
            httpsURLConnection.setConnectTimeout(3000);
            // For this use case, set HTTP method to GET.
            httpsURLConnection.setRequestMethod("GET");
            // Already true by default but setting just in case; needs to be true since this request
            // is carrying an input (response) body.
            httpsURLConnection.setDoInput(true);
            // Open communications link (network traffic occurs here).
            httpsURLConnection.connect();
            inputStream = new URL(stringImg).openStream();
            imgDescargada = BitmapFactory.decodeStream(httpsURLConnection.getInputStream());
            i = new Intent(DESCARGAIMAGEN_FIN_IMAGEN_ACTION);
            byteArray = convertirBitmap();
            i.putExtra("url", stringImg);
            i.putExtra("img", byteArray);
            LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
        } catch (IOException e) {
            i = new Intent(DESCARGAIMAGEN_ERROR_IMAGEN_ACTION);
            i.putExtra("url", stringImg);
            LocalBroadcastManager.getInstance(getBaseContext()).sendBroadcast(i);
        } finally {
            //close the current connection
            if (httpsURLConnection != null)
                httpsURLConnection.disconnect();
        }
        if (mFin) {
           i=new Intent(DESCARGAIMAGEN_CANCEL_ACTION);
           LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
        } else {
            i = new Intent(DESCARGAIMAGEN_FIN_ACTION);
            LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(i);
        }

    }

    private byte[] convertirBitmap() {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        imgDescargada.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mFin = true;
    }
}
