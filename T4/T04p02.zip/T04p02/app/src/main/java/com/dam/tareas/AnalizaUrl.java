package com.dam.tareas;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.dam.vista.R;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;

public class AnalizaUrl extends AsyncTask<Void, Void, String> {

    public static final String BROADCAST_CONN = "com.T04p02.sending_conn";
    public static final String BROADCAST_INI = "com.T04p02.sending_ini";
    public static final String BROADCAST_SEND = "com.T04p02.sending_result";
    public static final String BROADCAST_ERROR = "com.T04p02.sending_error";
    public static final String BROADCAST_END = "com.T04p02.sending_end";

    private Context mContext;
    private String mUrl;
    private Intent i;
    private ArrayList<String> urls;

    public AnalizaUrl(Context context, String url) {
        mContext = context;
        mUrl = url;
    }


    @Override
    protected void onPreExecute() {

        super.onPreExecute();
        ConnectivityManager connectivityManager = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if (networkInfo == null || !networkInfo.isConnected() ||
                    (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                            && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
                i = new Intent(BROADCAST_CONN);
                i.putExtra("start", mContext.getString(R.string.internetKO));
                LocalBroadcastManager.getInstance(mContext).sendBroadcast(i);
                cancel(true);
            } else {
                i = new Intent(BROADCAST_INI);
                i.putExtra("start", mContext.getString(R.string.msg_AnalisisUrlIniciado));
                LocalBroadcastManager.getInstance(mContext).sendBroadcast(i);
            }

        } else {
            i = new Intent(BROADCAST_INI);
            i.putExtra("start", mContext.getString(R.string.internetKO));
            LocalBroadcastManager.getInstance(mContext).sendBroadcast(i);
            cancel(true);
        }
    }


    @Override
    protected String doInBackground(Void... voids) {
        //catch first array parameter & converts into a url type
        URL url = null;
        try {
            url = new URL(mUrl);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        /**
         * Given a URL, sets up a connection and gets the HTTP response body from the server.
         * If the network request is successful, it returns the response body in String form. Otherwise,
         * it will throw an IOException.
         */
        InputStream stream = null;
        HttpsURLConnection connection = null;
        String result = null;
        try {
            connection = (HttpsURLConnection) url.openConnection();
            // Timeout for reading InputStream arbitrarily set to 3000ms.
            connection.setReadTimeout(3000);
            // Timeout for connection.connect() arbitrarily set to 3000ms.
            connection.setConnectTimeout(3000);
            // For this use case, set HTTP method to GET.
            connection.setRequestMethod("GET");
            // Already true by default but setting just in case; needs to be true since this request
            // is carrying an input (response) body.
            connection.setDoInput(true);
            // Open communications link (network traffic occurs here).
            connection.connect();

            int responseCode = connection.getResponseCode();
            if (responseCode != HttpsURLConnection.HTTP_OK) {
                throw new IOException("HTTP error code: " + responseCode);
            }
            // Retrieve the response body as an InputStream.
            stream = connection.getInputStream();

            if (stream != null) {
                // Converts Stream to String with max length of 500.
                result = readStream(stream, 1000000);
                urls = buscarUrl(result);

            }
        } catch (IOException ioException) {
            i = new Intent(BROADCAST_ERROR);
            i.putExtra("error", mContext.getString(R.string.msg_AnalisisUrlError));
            LocalBroadcastManager.getInstance(mContext).sendBroadcast(i);
        } finally {
            // Close Stream and disconnect HTTPS connection.
            if (stream != null) {
                try {
                    stream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                connection.disconnect();
            }
        }
        return result;
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);


        //send local broadcast with result if result var contains any data else send localbroadcast with info
        if (!result.isEmpty()) {
            i = new Intent(BROADCAST_SEND);
            i.putExtra("end", mContext.getString(R.string.msg_AnalisisUrlFinalizado));
            i.putExtra("result", urls);
            LocalBroadcastManager.getInstance(mContext).sendBroadcast(i);
        }
    }

    /**
     * Converts the contents of an InputStream to a String.
     */
    public String readStream(InputStream stream, int maxReadSize)
            throws IOException, UnsupportedEncodingException {
        Reader reader = null;
        reader = new InputStreamReader(stream, "UTF-8");
        char[] rawBuffer = new char[maxReadSize];
        int readSize;
        StringBuffer buffer = new StringBuffer();
        while (((readSize = reader.read(rawBuffer)) != -1) && maxReadSize > 0) {
            if (readSize > maxReadSize) {
                readSize = maxReadSize;
            }
            buffer.append(rawBuffer, 0, readSize);
            maxReadSize -= readSize;
        }
        return buffer.toString();
    }

    public ArrayList<String> buscarUrl(String result) {
        urls = new ArrayList<>();
        String[] parts = result.split("\"");
        Pattern pattern = Pattern.compile("(https?:\\/\\/.*\\.(?:png))");
        for (String trozos : parts) {
            Matcher matcher = pattern.matcher(trozos);
            while (matcher.find()) {
                urls.add(trozos);
            }
        }
        Log.i("w",String.valueOf(urls.size()));
        return urls;
    }
}

