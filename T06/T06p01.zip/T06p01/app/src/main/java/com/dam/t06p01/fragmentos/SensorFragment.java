package com.dam.t06p01.fragmentos;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.dam.t06p01.R;
import com.dam.t06p01.vistamodelo.Alarm;
import com.dam.t06p01.vistamodelo.Sensores;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SensorFragment extends Fragment {

    private Button btMake, btStop;
    private ImageView ivAlarm;
    private EditText etX, etXmin, etXmax, etY, etYmin, etYmax, etZ, etZmin, etZmax;
    private OnFragmentSensorListener mListener;
    private float[] values;

    public SensorFragment() {
        // Required empty public constructor
    }

    public interface OnFragmentSensorListener {

        void onMakeAlarm(Alarm alarm,float ... values);

        void onStopAlarm();

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentSensorListener) {
            mListener = (OnFragmentSensorListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_sensor, container, false);

        //FindViewByIds
        btMake = v.findViewById(R.id.btMake);
        btStop = v.findViewById(R.id.btStop);
        ivAlarm = v.findViewById(R.id.ivAlarm);
        etX = v.findViewById(R.id.etX);
        etXmin = v.findViewById(R.id.etXMin);
        etXmax = v.findViewById(R.id.etXMax);
        etY = v.findViewById(R.id.etY);
        etYmin = v.findViewById(R.id.etYMin);
        etYmax = v.findViewById(R.id.etYMax);
        etZ = v.findViewById(R.id.etZ);
        etZmin = v.findViewById(R.id.etZMin);
        etZmax = v.findViewById(R.id.etZMax);

        //inits
        etX.setEnabled(false);
        etY.setEnabled(false);
        etZ.setEnabled(false);
        etXmin.requestFocus();


        //listeners
        btMake.setOnClickListener(bt_onclick);
        btStop.setOnClickListener(bt_onclick);

        return v;
    }

    public void setValues(float[] values, String color) {
        this.values=values;
        etX.setText(String.format(Locale.getDefault(), "%.2f", values[0]));
        etY.setText(String.format(Locale.getDefault(), "%.2f", values[1]));
        etZ.setText(String.format(Locale.getDefault(), "%.2f", values[2]));
        switch (color) {
            case "red":
                ivAlarm.setColorFilter(Color.RED);
                break;
            case "yellow":
                ivAlarm.setColorFilter(Color.YELLOW);
                break;
        }

    }

    private View.OnClickListener bt_onclick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btMake:
                    if (!Sensores.getInstance().isSenActivos()) {
                        Snackbar.make(getActivity().findViewById(android.R.id.content), getString(R.string.any_sensors), Snackbar.LENGTH_SHORT).show();
                        return;
                    }
                    Alarm alarm=Alarm.getInstance();
                    Toast.makeText(getContext(), R.string.alarm_ok, Toast.LENGTH_SHORT).show();
                    enabled(false);
                    if (!etXmax.getText().toString().equals("") && !etXmin.getText().toString().equals("")) {
                        alarm.setxMax(Float.parseFloat(etXmax.getText().toString()));
                        alarm.setxMin(Float.parseFloat(etXmin.getText().toString()));
                        mListener.onMakeAlarm(alarm,values[0]);
                    }else if (!etYmax.getText().toString().equals("") && !etYmin.getText().toString().equals("")) {
                        alarm.setyMax(Float.parseFloat(etYmax.getText().toString()));
                        alarm.setyMin(Float.parseFloat(etYmin.getText().toString()));
                        mListener.onMakeAlarm(alarm,values[0],values[1]);
                    }else if (!etZmax.getText().toString().equals("") && !etZmin.getText().toString().equals("")) {
                        alarm.setzMax(Float.parseFloat(etZmax.getText().toString()));
                        alarm.setzMax(Float.parseFloat(etZmin.getText().toString()));
                        mListener.onMakeAlarm(alarm,values[0],values[1],values[2]);
                    }else {
                        Snackbar.make(getActivity().findViewById(android.R.id.content),getString(R.string.alarm_ko),Snackbar.LENGTH_SHORT).show();
                    }
                    break;
                case R.id.btStop:
                    Snackbar.make(getActivity().findViewById(android.R.id.content),getString(R.string.alarm_ko),Snackbar.LENGTH_SHORT).show();
                    enabled(true);
                    mListener.onStopAlarm();
                    limpiar();
                    break;
            }
        }
    };

    private void enabled(boolean activated) {
        if (activated) {
            etXmax.setEnabled(true);
            etXmin.setEnabled(true);
            etYmax.setEnabled(true);
            etYmin.setEnabled(true);
            etZmax.setEnabled(true);
            etZmin.setEnabled(true);
        } else {
            etXmax.setEnabled(false);
            etXmin.setEnabled(false);
            etYmax.setEnabled(false);
            etYmin.setEnabled(false);
            etZmax.setEnabled(false);
            etZmin.setEnabled(false);
        }
    }

    private void limpiar() {
        etXmax.setText("");
        etXmin.setText("");
        etYmax.setText("");
        etYmin.setText("");
        etZmax.setText("");
        etZmin.setText("");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
}
