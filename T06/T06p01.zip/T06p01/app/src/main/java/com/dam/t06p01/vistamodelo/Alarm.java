package com.dam.t06p01.vistamodelo;

import android.util.Log;

public class Alarm {
    private float xMin;
    private float xMax;
    private float yMin;
    private float yMax;
    private float zMin;
    private float zMax;

    private static Alarm alarm;

    public float getxMin() {
        return xMin;
    }

    public void setxMin(float xMin) {
        this.xMin = xMin;
    }

    public float getxMax() {
        return xMax;
    }

    public void setxMax(float xMax) {
        this.xMax = xMax;
    }

    public float getyMin() {
        return yMin;
    }

    public void setyMin(float yMin) {
        this.yMin = yMin;
    }

    public float getyMax() {
        return yMax;
    }

    public void setyMax(float yMax) {
        this.yMax = yMax;
    }

    public float getzMin() {
        return zMin;
    }

    public void setzMin(float zMin) {
        this.zMin = zMin;
    }

    public float getzMax() {
        return zMax;
    }

    public void setzMax(float zMax) {
        this.zMax = zMax;
    }

    //methods
    public static Alarm getInstance(){

        if(alarm==null)
            alarm=new Alarm();
        return alarm;
    }

    public boolean setAlarm(Alarm alarm,float ...params){

        if(params.length==1) {
            if (params[0]/alarm.getxMin()<1 || params[0]/alarm.getxMax() >1 )
                    return true;
        }else if(params.length==2) {
            if (params[0]/alarm.getxMin() <1  || params[0]/alarm.getxMax() > 1
                    || params[1]/alarm.getyMin() > 1 || params[1]/alarm.getyMax() < 1)
            return true;
        }else {
            if (params[0]/alarm.getxMin() < 1 || params[0]/alarm.getxMax() > 1
                    || params[1]/alarm.getyMin()< 1 || params[1]/alarm.getyMax() > 1
                    || params[2]/alarm.getzMin() < 1 || params[2]/alarm.getzMax() > 1)
                return true;
        }
        return false;
    }
}
