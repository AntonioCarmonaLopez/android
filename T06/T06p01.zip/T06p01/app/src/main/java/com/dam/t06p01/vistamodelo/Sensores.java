package com.dam.t06p01.vistamodelo;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import java.util.ArrayList;
import java.util.List;

public class Sensores {

    // Singleton
    private static Sensores mSensores;

    public static Sensores getInstance() {
        if (mSensores == null)
            mSensores = new Sensores();
        return mSensores;
    }

    private List<String> mSenList;
    private boolean mSenActivos;
    private String mSenInfo;

    private Sensores() {
        this.mSenList = new ArrayList<>();
        this.mSenActivos = false;
        this.mSenInfo = "";
    }

    public List<String> getSenList() {
        return mSenList;
    }

    public boolean isSenActivos() {
        return mSenActivos;
    }

    public String getSenInfo() {
        return mSenInfo;
    }

    public void obtenerSensores(Context context) {
        SensorManager senMan = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (senMan != null) {
            List<Sensor> lista = senMan.getSensorList(Sensor.TYPE_ALL);
            mSenList.clear();
            mSenList.add("...");
            for (Sensor s : lista)
                mSenList.add(s.getType() + " " + s.getName());
        }
    }

    public boolean activarSensores(Context context, String sensor) {
        SensorManager senMan = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (senMan != null) {
            Sensor s = senMan.getDefaultSensor(Integer.parseInt(sensor.split(" ")[0]));
            if (s != null) {
                mSenInfo = "INFO: " + "\n" +
                        "Vendor: " + s.getVendor() + "\n" +
                        "Version: " + s.getVersion() + "\n" +
                        "Resolution: " + s.getResolution() + "\n" +
                        "MaxRange: " + s.getMaximumRange() + "\n" +
                        "minDelay: " + s.getMinDelay() + "\n" +
                        "Power: " + s.getPower() + "\n";
                senMan.registerListener((SensorEventListener) context, s, SensorManager.SENSOR_DELAY_NORMAL);
                mSenActivos = true;
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    public boolean desactivarSensores(Context context) {
        SensorManager senMan = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (senMan != null) {
            senMan.unregisterListener((SensorEventListener) context);
            mSenActivos = false;
            return true;
        }
        return false;
    }

}
