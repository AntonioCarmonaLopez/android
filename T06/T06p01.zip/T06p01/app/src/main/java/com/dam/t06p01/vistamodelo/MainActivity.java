package com.dam.t06p01.vistamodelo;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.dam.t06p01.R;

import com.dam.t06p01.fragmentos.SensorFragment;
import com.google.android.material.snackbar.Snackbar;


public class MainActivity extends AppCompatActivity
        implements SensorEventListener,
        SensorFragment.OnFragmentSensorListener {

    private Spinner spSensor;
    private boolean alarmON;
    private Alarm alarm;
    private String color;
    private int nParams;
    private String activedSensor;
    private float[] values;
    private SensorFragment mFragment;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // FindViewByIds
        spSensor = findViewById(R.id.spSensors);


        // Inits
        Sensores.getInstance().obtenerSensores(this);
        mFragment = (SensorFragment) getSupportFragmentManager().findFragmentById(R.id.fragment);


        ArrayAdapter<String> adaptadorSen = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                Sensores.getInstance().getSenList());
        spSensor.setAdapter(adaptadorSen);

        // Listeners
        spSensor.setOnItemSelectedListener(spSensor_OnItemSelectedListener);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.exit:
                confExit();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void confExit() {
        Snackbar snackbar = Snackbar.make(findViewById(R.id.constraint), getString(R.string.msg_exit), Snackbar.LENGTH_LONG);
        snackbar.setAction(getString(R.string.yes), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        snackbar.show();
    }

    private AdapterView.OnItemSelectedListener spSensor_OnItemSelectedListener = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            if (Sensores.getInstance().isSenActivos()) {
                if (Sensores.getInstance().desactivarSensores(MainActivity.this)) {
                    Snackbar.make(findViewById(android.R.id.content), R.string.disabling_ok, Snackbar.LENGTH_SHORT).show();
                } else {
                    Snackbar.make(findViewById(android.R.id.content), R.string.disabling_ko, Snackbar.LENGTH_SHORT).show();
                }
            }
            if (position > 0) {
                if (!Sensores.getInstance().isSenActivos()) {
                    activedSensor = spSensor.getSelectedItem().toString();
                    if (Sensores.getInstance().activarSensores(MainActivity.this, activedSensor)) {
                        Snackbar.make(findViewById(android.R.id.content), R.string.act_sensors, Snackbar.LENGTH_SHORT).show();
                    } else {
                        Snackbar.make(findViewById(android.R.id.content), R.string.act_sensor_ko, Snackbar.LENGTH_SHORT).show();
                    }
                }
            } else {

            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    };

    @Override
    public void onSensorChanged(SensorEvent event) {
        values = event.values;
        if (alarmON) {
            checkValues(nParams);
        } else {
            setColor("yellow");
            mFragment.setValues(event.values, getColor());
        }
    }

    private void checkValues(int nParams) {
        switch (nParams) {
            case 1:
                if (alarm.setAlarm(alarm, values[0])) {
                    setColor("red");
                    mFragment.setValues(values, getColor());

                } else {
                    setColor("yellow");
                    mFragment.setValues(values, getColor());
                }
                break;
            case 2:
                if (alarm.setAlarm(alarm, values[0], values[1])) {
                    setColor("red");
                    mFragment.setValues(values, getColor());
                } else {
                    setColor("yellow");
                    mFragment.setValues(values, getColor());
                }
                break;
            case 3:
                if (alarm.setAlarm(alarm, values[0], values[1], values[2])) {
                    setColor("red");
                    mFragment.setValues(values, getColor());
                } else {
                    setColor("yellow");
                    mFragment.setValues(values, getColor());
                }
                break;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onMakeAlarm(Alarm alarm, float... values) {

        this.alarm = alarm;
        nParams = values.length;
        alarmON = true;
        checkValues(nParams);
    }

    @Override
    public void onStopAlarm() {
        alarmON = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (Sensores.getInstance().isSenActivos()) {
            if (Sensores.getInstance().desactivarSensores(this)) {
                Snackbar.make(findViewById(android.R.id.content), R.string.sensors_disabling, Snackbar.LENGTH_SHORT).show();
            } else {
                Snackbar.make(findViewById(android.R.id.content), R.string.sensors_ko, Snackbar.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putString("sensor", activedSensor);
        state.putString("color", getColor());

    }

    @Override
    protected void onRestoreInstanceState(Bundle estado) {
        super.onRestoreInstanceState(estado);
        //load sensor's list again
        Sensores.getInstance().obtenerSensores(this);
        //spinner
        ArrayAdapter<String> adaptadorSen = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                Sensores.getInstance().getSenList());
        spSensor.setAdapter(adaptadorSen);
        //activted sensor again
        Sensores.getInstance().activarSensores(this, "sensor");
        //send values & color to fragment
        SensorFragment mFragment = (SensorFragment) getSupportFragmentManager().findFragmentById(R.id.fragment);
        mFragment.setValues(values, getColor());

    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        confExit();
    }
}


