package com.dam.t07p01.modelo;

import java.util.ArrayList;
import java.util.List;

public class Datos {

    /* Singleton **********************************************************************************/

    private static Datos mDatos = null;

    private List<Departamento> mDptos;
    private List<Incidencia> mIncs;

    /* Constructores ******************************************************************************/

    private Datos() {
        mDptos = new ArrayList<>();
        mIncs = new ArrayList<>();
    }

    /* Métodos ************************************************************************************/

    public static Datos getInstance() {
        if (mDatos == null)
            mDatos = new Datos();
        return mDatos;
    }

    public List<Departamento> getDptos() {
        return mDptos;
    }

    public List<Incidencia> getIncs() {
        return mIncs;
    }

}
