package com.dam.t07p01.vistamodelo;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.dam.t07p01.modelo.Departamento;
import com.dam.t07p01.modelo.Incidencia;

import java.util.List;

public class IncsViewModel extends AndroidViewModel {

    /* ViewModel Incs ****************************************************************************/

    private MutableLiveData<List<Incidencia>> mIncs;
    private Context mContext;
    private Departamento mLogin;
    private MainViewModel mVM;

    public IncsViewModel(@NonNull Application application) {
        super(application);
        mIncs = new MutableLiveData<>();
        mContext = application;
        mLogin= null;
    }

    public Departamento getLogin() {
        return mLogin;
    }

    public void setLogin(Departamento login) {
        mLogin = login;
    }

    public LiveData<List<Incidencia>> getIncs() {
        mIncs.setValue(IncLogica.recuperarIncidencias(mLogin));
        return mIncs;
    }

    public List<Incidencia> getIncsNoLive() {
        return IncLogica.recuperarIncidencias(mLogin);
    }

    public boolean altaIncidencia(Incidencia inc) {
        if (IncLogica.altaIncidencia(inc)) {
            mIncs.setValue(IncLogica.recuperarIncidencias(mLogin));
            return true;
        } else {
            return false;
        }
    }

    public boolean editarIncidencia(Incidencia inc) {
        if (IncLogica.editarIncidencia(inc)) {
            mIncs.setValue(IncLogica.recuperarIncidencias(mLogin));
            return true;
        } else {
            return false;
        }
    }

    public boolean bajaIncidencia(Incidencia inc) {
        if (IncLogica.bajaIncidencia(inc)) {
            mIncs.setValue(IncLogica.recuperarIncidencias(mLogin));
            return true;
        } else {
            return false;
        }
    }

    public boolean recuperarDatosIncidencias(Departamento mDpto) {
        return IncLogica.recuperarDatosIncidencias(mContext,mDpto);
    }

    public boolean guardarDatosIncidencias() {
        return IncLogica.guardarDatosIncidencias(mContext);
    }

}
