package com.dam.t07p01.vista;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.dam.t07p01.R;
import com.dam.t07p01.modelo.Departamento;
import com.dam.t07p01.vista.dialogos.DlgConfirmacion;
import com.dam.t07p01.vista.fragmentos.BusDptosFragment;
import com.dam.t07p01.vista.fragmentos.MtoDptosFragment;
import com.dam.t07p01.vistamodelo.DptsViewModel;
import com.google.android.material.snackbar.Snackbar;

public class DptosActivity extends AppCompatActivity
        implements BusDptosFragment.BusDptosFragInterface,
        MtoDptosFragment.MtoDptosFragInterface,
        DlgConfirmacion.DlgConfirmacionListener {

    private NavController mNavC;

    private DptsViewModel mDptosVM;
    private Departamento mLogin;
    private Departamento mDptoAEliminar;
    private boolean mDatosModificados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dptos);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // FindViewByIds

        // Inits
        mNavC = Navigation.findNavController(this, R.id.navhostfrag_dptos);
        mDptosVM = ViewModelProviders.of(this).get(DptsViewModel.class);

        // Recuperamos el dpto login
        Intent i = getIntent();
        if (i != null) {
            Bundle b = i.getExtras();
            if (b != null) {
                mLogin = b.getParcelable("login");
            }
        }
        if (mLogin == null) {
            Snackbar.make(findViewById(android.R.id.content), R.string.msg_NoLogin, Snackbar.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Recuperamos Dptos
        if (mDptosVM.recuperarDatosDepartamentos()) {
            //Snackbar.make(findViewById(android.R.id.content), R.string.msg_DatosRecuperadosOK, Snackbar.LENGTH_SHORT).show();
        } else {
            Snackbar.make(findViewById(android.R.id.content), R.string.msg_ErrorFicheros, Snackbar.LENGTH_SHORT).show();
            finish();
            return;
        }
        mDatosModificados = false;

        // Listeners

    }

    @Override
    protected void onDestroy() {
        if (mDatosModificados) {
            // Guardamos Dptos
            if (mDptosVM.guardarDatosDepartamentos()) {
                //Snackbar.make(findViewById(android.R.id.content), R.string.msg_DatosGuardadosOK, Snackbar.LENGTH_SHORT).show();
            } else {
                Snackbar.make(findViewById(android.R.id.content), R.string.msg_ErrorFicheros, Snackbar.LENGTH_SHORT).show();
            }
            mDatosModificados = false;
        }
        super.onDestroy();
    }

    @Override
    public void onCrearBusDptosFrag() {
        // Lanzamos MtoDptosFragment
        Bundle bundle = new Bundle();
        bundle.putInt("op", MtoDptosFragment.OP_CREAR);
        mNavC.navigate(R.id.action_busDptosFragment_to_mtoDptosFragment, bundle);
    }

    @Override
    public void onEditarBusDptosFrag(Departamento dpto) {
        // Lanzamos MtoDptosFragment
        Bundle bundle = new Bundle();
        bundle.putInt("op", MtoDptosFragment.OP_EDITAR);
        bundle.putParcelable("dpto", dpto);
        mNavC.navigate(R.id.action_busDptosFragment_to_mtoDptosFragment, bundle);
    }

    @Override
    public void onEliminarBusDptosFrag(Departamento dpto) {
        mDptoAEliminar = dpto;
        // Lanzamos DlgConfirmacion
        Bundle bundle = new Bundle();
        bundle.putInt("titulo", R.string.app_name);
        bundle.putInt("mensaje", R.string.msg_DlgConfirmacion_Eliminar);
        mNavC.navigate(R.id.action_global_dlgConfirmacionDptos, bundle);
    }

    @Override
    public void onCancelarMtoDptosFrag() {
        // Cerramos MtoDptosFragment
        mNavC.navigateUp();
    }

    @Override
    public void onAceptarMtoDptosFrag(int op, Departamento dpto) {
        switch (op) {
            case MtoDptosFragment.OP_CREAR:
                if (mDptosVM.altaDepartamento(dpto)) {
                    mDatosModificados = true;
                    Snackbar.make(findViewById(android.R.id.content), R.string.msg_AltaDepartamentoOK, Snackbar.LENGTH_SHORT).show();
                } else {
                    Snackbar.make(findViewById(android.R.id.content), R.string.msg_AltaDepartamentoKO, Snackbar.LENGTH_SHORT).show();
                }
                break;
            case MtoDptosFragment.OP_EDITAR:
                if (mDptosVM.editarDepartamento(dpto)) {
                    mDatosModificados = true;
                    Snackbar.make(findViewById(android.R.id.content), R.string.msg_EditarDepartamentoOK, Snackbar.LENGTH_SHORT).show();
                } else {
                    Snackbar.make(findViewById(android.R.id.content), R.string.msg_EditarDepartamentoKO, Snackbar.LENGTH_SHORT).show();
                }
                break;
            case MtoDptosFragment.OP_ELIMINAR:
                break;
        }

        // Cerramos MtoDptosFragment
        mNavC.navigateUp();
    }

    @Override
    public void onDlgConfirmacionPositiveClick(DialogFragment dialog) {
        if (mDptoAEliminar != null) {
            // El dpto a eliminar podría ser null si hay un giro mientras se muestra el dlg de confirmación!!
            // Esto se podría arreglar implementando el onSaveInstanteState.
            if (mDptosVM.bajaDepartamento(mDptoAEliminar)) {
                mDatosModificados = true;
                Snackbar.make(findViewById(android.R.id.content), R.string.msg_BajaDepartamentoOK, Snackbar.LENGTH_SHORT).show();
            } else {
                Snackbar.make(findViewById(android.R.id.content), R.string.msg_BajaDepartamentoKO, Snackbar.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onDlgConfirmacionNegativeClick(DialogFragment dialog) {
        ;
    }

}
