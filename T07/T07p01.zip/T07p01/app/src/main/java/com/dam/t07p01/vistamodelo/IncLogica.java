package com.dam.t07p01.vistamodelo;

import android.content.Context;
import android.util.Log;

import com.dam.t07p01.modelo.Datos;
import com.dam.t07p01.modelo.Departamento;
import com.dam.t07p01.modelo.Ficheros;
import com.dam.t07p01.modelo.Incidencia;

import java.util.ArrayList;
import java.util.List;

public class IncLogica {

    /* Métodos Lógica Incs ***********************************************************************/

    public static List<Incidencia> recuperarIncidencias(Departamento departamento) {
        List<Incidencia> tempIncidencias = new ArrayList<>();

        for (Incidencia i : Datos.getInstance().getIncs()) {
            if (i.getIdDpto() == departamento.getId() || departamento.getId() == 0) {
                tempIncidencias.add(i);
            }
        }
        return tempIncidencias;
    }

    public static boolean existeIncidencia(Incidencia inc) {
        for (Incidencia i : Datos.getInstance().getIncs())
            if (i.getId().equals(inc.getId()))
                return true;
        return false;
    }

    public static boolean altaIncidencia(Incidencia inc) {
        if (existeIncidencia(inc)) return false;
        return Datos.getInstance().getIncs().add(inc);
    }

    public static boolean editarIncidencia(Incidencia inc) {
        if (!existeIncidencia(inc)) return false;
        for (Incidencia i : Datos.getInstance().getIncs())
            if (i.getId().equals(inc.getId())) {
                i.setIdDpto(inc.getIdDpto());
                i.setId(inc.getId());
                i.setFecha(inc.getFecha());
                i.setDescripcion(inc.getDescripcion());
                i.setTipo(inc.getTipo());
                i.setEstado(inc.isEstado());
                i.setResolucion(inc.getResolucion());
                break;
            }
        return true;
    }

    public static boolean bajaIncidencia(Incidencia inc) {
        if (!existeIncidencia(inc)) return false;
        for (Incidencia i : Datos.getInstance().getIncs())
            if (i.getId().equals(inc.getId())) {
                Datos.getInstance().getIncs().remove(inc);
                break;
            }
        return true;
    }

    public static boolean bajaIncidenciaXDpto(Departamento departamento) {

        for (Incidencia i : Datos.getInstance().getIncs())
            if (i.getIdDpto()==departamento.getId()) {
                Datos.getInstance().getIncs().remove(i);
                break;
            }
        return true;
    }

    public static boolean recuperarDatosIncidencias(Context context,Departamento dpto) {
        try {
            Datos.getInstance().getIncs().clear();
            Ficheros.recuperarDatosIncidencias(context, Datos.getInstance().getIncs());
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static boolean guardarDatosIncidencias(Context context) {
        try {
            Ficheros.guardarDatosIncidencias(context, Datos.getInstance().getIncs());
        } catch (Exception e) {
            return false;
        }
        return true;
    }

}
