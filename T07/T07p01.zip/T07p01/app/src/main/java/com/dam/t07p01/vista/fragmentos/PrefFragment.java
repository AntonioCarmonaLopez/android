package com.dam.t07p01.vista.fragmentos;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

import com.dam.t07p01.R;
import com.dam.t07p01.modelo.Departamento;

public class PrefFragment extends PreferenceFragmentCompat
        implements SharedPreferences.OnSharedPreferenceChangeListener {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.preferences, rootKey);
        Departamento login = null;
        if (getArguments() != null) {
            login = getArguments().getParcelable("login");
        }
        if (login != null && login.getId() == 0) { // Admin
            Preference pref,pref1;
            pref = findPreference(getString(R.string.ficheroDpto_key));
            pref1 = findPreference(getString(R.string.ficheroInc_key));
            if (pref != null && pref1 !=null){
                pref.setVisible(true);
                pref1.setVisible(true);
            }
            pref = findPreference(getString(R.string.tipoFichero_key));
            pref1 = findPreference(getString(R.string.tipoFichero_key));
            if (pref != null && pref1 !=null){
                pref.setVisible(true);
                pref1.setVisible(true);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        // Esto no funciona bien, ya que cuando un usuario no admin cambia un valor,
        // vuelve a poner el valor por defecto, no el que había!!
        // Lo he mejorado haciendo visible e invisible la preferencia en onCreatePreferences,
        // el código siguiente lo dejo para mostrar el Toast de cambio de datos!!
        Departamento login = null;
        if (getArguments() != null) {
            login = getArguments().getParcelable("login");
        }
        if (key.equals(getResources().getString(R.string.ficheroDpto_key))) {
            if (login != null && login.getId() == 0) { // Admin
                Toast.makeText(requireActivity(), R.string.msg_CambioFichero, Toast.LENGTH_LONG).show();
            } else {
                sharedPreferences.edit().putString(key, getResources().getString(R.string.ficheroDpto_default)).apply();
                Toast.makeText(requireActivity(), R.string.msg_LoginPermisos, Toast.LENGTH_LONG).show();
            }
        } else if (key.equals(getResources().getString(R.string.tipoFichero_key))) {
            if (login != null && login.getId() == 0) { // Admin
                Toast.makeText(requireActivity(), R.string.msg_CambioFichero, Toast.LENGTH_LONG).show();
            } else {
                sharedPreferences.edit().putString(key, getResources().getString(R.string.tipoFichero_default)).apply();
                Toast.makeText(requireActivity(), R.string.msg_LoginPermisos, Toast.LENGTH_LONG).show();
            }
        }
    }

}
