package com.dam.t07p01.vista.fragmentos;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.dam.t07p01.R;
import com.dam.t07p01.modelo.Departamento;
import com.dam.t07p01.modelo.Incidencia;
import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MtoIncsFragment extends Fragment {

    private TextView tvCabecera;
    private EditText etDptoId, etId, etFecha, etDescripcion, etResolucion;
    private RadioButton rbRMA, rbRMI;
    private CheckBox cbEstado;
    private Button btCancelar, btAceptar;

    private int mOp;    // Operación a realizar
    private Incidencia mInc;
    private Departamento mDpto;

    public static final int OP_ELIMINAR = 1;
    public static final int OP_EDITAR = 2;
    public static final int OP_CREAR = 3;

    public static final String TAG = "MtoIncsFragment";
    private MtoIncsFragInterface mListener;

    public interface MtoIncsFragInterface {
        void onCancelarMtoIncsFrag();

        void onAceptarMtoIncsFrag(int op, Incidencia inc);
    }

    public MtoIncsFragment() {
        // Required empty public constructor
    }

    public static MtoIncsFragment newInstance(Bundle arguments) {
        MtoIncsFragment frag = new MtoIncsFragment();
        if (arguments != null) {
            frag.setArguments(arguments);
        }
        return frag;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof MtoIncsFragInterface) {
            mListener = (MtoIncsFragInterface) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement MtoIncsFragInterface");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mOp = getArguments().getInt("op");
            mInc = getArguments().getParcelable("inc");
            mDpto = getArguments().getParcelable("dpto");
        } else {
            mOp = -1;
            mInc = null;
            mDpto = null;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_mto_incs, container, false);

        // FindViewByIds
        tvCabecera = v.findViewById(R.id.tvIncCabecera);
        etDptoId = v.findViewById(R.id.etIncDpto);
        etId = v.findViewById(R.id.etIncId);
        etFecha = v.findViewById(R.id.etIncFecha);
        etDescripcion = v.findViewById(R.id.etIncDescripcion);
        rbRMA = v.findViewById(R.id.rbIncTipoRMA);
        rbRMI = v.findViewById(R.id.rbIncTipoRMI);
        cbEstado = v.findViewById(R.id.cbIncEstado);
        etResolucion = v.findViewById(R.id.etIncResolucion);
        btCancelar = v.findViewById(R.id.btCancelar);
        btAceptar = v.findViewById(R.id.btAceptar);

        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        // Inits
        if (mOp != -1) {                    // MtoIncsFragment requiere una operación válida!!
            btCancelar.setEnabled(true);
            btAceptar.setEnabled(true);

            switch (mOp) {
                case OP_CREAR:
                    Incidencia inc = new Incidencia();
                    tvCabecera.setText(getString(R.string.tv_Inc_Cabecera_Crear));
                    etDptoId.setText(String.valueOf(mDpto.getId()));
                    etDptoId.setEnabled(false);
                    etId.setText(inc.getId());
                    etId.setEnabled(false);
                    etFecha.setText(calcDate());
                    etFecha.setEnabled(false);
                    etResolucion.setEnabled(false);
                    break;
                case OP_EDITAR:
                    tvCabecera.setText(getString(R.string.tv_Inc_Cabecera_Editar));
                    etDptoId.setText(String.valueOf(mInc.getIdDpto()));
                    etDptoId.setEnabled(false);
                    etId.setText(mInc.getId());
                    etId.setEnabled(false);
                    etFecha.setText(mInc.getFecha());
                    etFecha.setEnabled(false);
                    etDescripcion.setText(mInc.getDescripcion());
                    if (mInc.getTipo().name().equals("RMA"))
                        rbRMA.setChecked(true);
                    else
                        rbRMI.setChecked(true);
                    if (mInc.isEstado())
                        cbEstado.setChecked(true);
                    etResolucion.setText(mInc.getResolucion());
                    etId.setEnabled(false);
                    break;
            }

            // Listeners
            btCancelar.setOnClickListener(btCancelar_OnClickListener);
            btAceptar.setOnClickListener(btAceptar_OnClickListener);

        } else {
            btCancelar.setEnabled(false);
            btAceptar.setEnabled(false);
        }
    }

    private String calcDate(){
        StringBuilder sb=new StringBuilder();
        Calendar date = new GregorianCalendar();

        int year = date.get(Calendar.YEAR);
        int month = date.get(Calendar.MONTH);
        int day = date.get(Calendar.DAY_OF_MONTH);

        sb.append(day).append("/").append(month).append("/").append(year);
        return sb.toString();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    private View.OnClickListener btCancelar_OnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            InputMethodManager imm = (InputMethodManager) requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

            if (mListener != null) {
                mListener.onCancelarMtoIncsFrag();
            }
        }
    };

    private View.OnClickListener btAceptar_OnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            InputMethodManager imm = (InputMethodManager) requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

            if (mListener != null) {
                if (!etDptoId.getText().toString().equals("") &&
                        !etId.getText().toString().equals("") &&
                        !etFecha.getText().toString().equals("")) {
                    String pattern = "mm/dd/yyyy";
                    Pattern cPattern = Pattern.compile(pattern);
                    Matcher matcher = cPattern.matcher(etFecha.getText().toString());
                    if(matcher.matches()) {
                        Snackbar.make(requireActivity().findViewById(android.R.id.content), R.string.msg_formato_fecha_ko, Snackbar.LENGTH_SHORT).show();
                        return;
                    }
                    // Creamos una nueva Incidencia, independientemente de la operación a realizar!!
                    mInc = new Incidencia();
                    mInc.setIdDpto(Integer.parseInt(etDptoId.getText().toString()));
                    mInc.setId(etId.getText().toString());
                    mInc.setFecha(etFecha.getText().toString());
                    mInc.setDescripcion(etDescripcion.getText().toString());
                    if (rbRMA.isChecked())
                        mInc.setTipo(Incidencia.TIPO.RMA);
                    else
                        mInc.setTipo(Incidencia.TIPO.RMI);
                    if (cbEstado.isChecked())
                        mInc.setEstado(true);
                    else
                        mInc.setEstado(false);
                    mInc.setResolucion("");
                    mListener.onAceptarMtoIncsFrag(mOp, mInc);
                } else {
                    Snackbar.make(requireActivity().findViewById(android.R.id.content), R.string.msg_FaltanDatosObligatorios, Snackbar.LENGTH_SHORT).show();
                }
            }
        }
    };

}
