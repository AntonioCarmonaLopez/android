package com.dam.t07p01.vista;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.dam.t07p01.R;
import com.dam.t07p01.modelo.Departamento;
import com.dam.t07p01.modelo.Incidencia;
import com.dam.t07p01.vista.dialogos.DlgConfirmacion;
import com.dam.t07p01.vista.fragmentos.BusDptosFragment;
import com.dam.t07p01.vista.fragmentos.BusIncsFragment;
import com.dam.t07p01.vista.fragmentos.MtoDptosFragment;
import com.dam.t07p01.vista.fragmentos.MtoIncsFragment;
import com.dam.t07p01.vistamodelo.IncsViewModel;
import com.google.android.material.snackbar.Snackbar;

public class IncsActivity extends AppCompatActivity
        implements BusIncsFragment.BusIncsFragInterface,
        MtoIncsFragment.MtoIncsFragInterface,
        DlgConfirmacion.DlgConfirmacionListener {

    private NavController mNavC;

    private IncsViewModel mIncsVM;
    private Departamento mLogin;
    private Incidencia mIncAEliminar;
    private boolean mDatosModificados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incs);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // FindViewByIds

        // Inits
        mNavC = Navigation.findNavController(this, R.id.navhostfrag_incs);
        mIncsVM = ViewModelProviders.of(this).get(IncsViewModel.class);

        // Recuperamos el dpto login
        Intent i = getIntent();
        if (i != null) {
            Bundle b = i.getExtras();
            if (b != null) {
                mLogin = b.getParcelable("login");
                mIncsVM.setLogin(mLogin);
            }
        }
        if (mLogin == null) {
            Snackbar.make(findViewById(android.R.id.content), R.string.msg_NoLogin, Snackbar.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Recuperamos Incs
        if (mIncsVM.recuperarDatosIncidencias(mLogin)) {
            //Snackbar.make(findViewById(android.R.id.content), R.string.msg_DatosRecuperadosOK, Snackbar.LENGTH_SHORT).show();
        } else {
            Snackbar.make(findViewById(android.R.id.content), R.string.msg_ErrorFicheros, Snackbar.LENGTH_SHORT).show();
            finish();
            return;
        }
        mDatosModificados = false;

        // Listeners

    }

    @Override
    protected void onDestroy() {
        if (mDatosModificados) {
            // Guardamos Incs
            if (mIncsVM.guardarDatosIncidencias()) {
                //Snackbar.make(findViewById(android.R.id.content), R.string.msg_DatosGuardadosOK, Snackbar.LENGTH_SHORT).show();
            } else {
                Snackbar.make(findViewById(android.R.id.content), R.string.msg_ErrorFicheros, Snackbar.LENGTH_SHORT).show();
            }
            mDatosModificados = false;
        }
        super.onDestroy();
    }

    @Override
    public void onCrearBusIncsFrag() {
        //recuperar departamento y enviarlos al fragmento MtoIncsFragment
        Bundle datos = new Bundle();
        datos=this.getIntent().getExtras();
        if(datos!=null) {
            Departamento dpto = datos.getParcelable("login");
            datos.putParcelable("dpto",dpto);
            datos.putInt("op", MtoIncsFragment.OP_CREAR);
            //MtoIncsFragment.newInstance(datos);
        }
        mNavC.navigate(R.id.action_busIncsFragment_to_mtoIncsFragment, datos);
    }

    @Override
    public void onEditarBusIncsFrag(Incidencia inc) {
        // Lanzamos MtoIncsFragment
        Bundle bundle = new Bundle();
        bundle.putInt("op", MtoIncsFragment.OP_EDITAR);
        bundle.putParcelable("inc", inc);
        mNavC.navigate(R.id.action_busIncsFragment_to_mtoIncsFragment, bundle);
    }

    @Override
    public void onEliminarBusIncsFrag(Incidencia inc) {
        mIncAEliminar = inc;
        // Lanzamos DlgConfirmacion
        Bundle bundle = new Bundle();
        bundle.putInt("titulo", R.string.app_name);
        bundle.putInt("mensaje", R.string.msg_DlgConfirmacion_Eliminar);
        mNavC.navigate(R.id.action_global_dlgConfirmacionIncs, bundle);
    }

    @Override
    public void onCancelarMtoIncsFrag() {
        // Cerramos MtoIncsFragment
        mNavC.navigateUp();
    }

    @Override
    public void onAceptarMtoIncsFrag(int op, Incidencia inc) {
        switch (op) {
            case MtoIncsFragment.OP_CREAR:
                if (mIncsVM.altaIncidencia(inc)) {
                    mDatosModificados = true;
                    Snackbar.make(findViewById(android.R.id.content), R.string.msg_AltaIncidenciaOK, Snackbar.LENGTH_SHORT).show();
                } else {
                    Snackbar.make(findViewById(android.R.id.content), R.string.msg_AltaIncidenciaKO, Snackbar.LENGTH_SHORT).show();
                }
                break;
            case MtoIncsFragment.OP_EDITAR:
                if (mIncsVM.editarIncidencia(inc)) {
                    mDatosModificados = true;
                    Snackbar.make(findViewById(android.R.id.content), R.string.msg_EditarIncidenciaOK, Snackbar.LENGTH_SHORT).show();
                } else {
                    Snackbar.make(findViewById(android.R.id.content), R.string.msg_EditarIncidenciaKO, Snackbar.LENGTH_SHORT).show();
                }
                break;
            case MtoIncsFragment.OP_ELIMINAR:
                break;
        }

        // Cerramos MtoIncsFragment
        mNavC.navigateUp();
    }

    @Override
    public void onDlgConfirmacionPositiveClick(DialogFragment dialog) {
        if (mIncAEliminar != null) {
            // La incidencia a eliminar podría ser null si hay un giro mientras se muestra el dlg de confirmación!!
            // Esto se podría arreglar implementando el onSaveInstanteState.
            if (mIncsVM.bajaIncidencia(mIncAEliminar)) {
                mDatosModificados = true;
                Snackbar.make(findViewById(android.R.id.content), R.string.msg_BajaIncidenciaOK, Snackbar.LENGTH_SHORT).show();
            } else {
                Snackbar.make(findViewById(android.R.id.content), R.string.msg_BajaIncidenciaKO, Snackbar.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onDlgConfirmacionNegativeClick(DialogFragment dialog) {
        ;
    }


    @Override protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putParcelable("inc", mIncAEliminar);
    }


    @Override protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        mIncAEliminar = bundle.getParcelable("inc");
    }
}
