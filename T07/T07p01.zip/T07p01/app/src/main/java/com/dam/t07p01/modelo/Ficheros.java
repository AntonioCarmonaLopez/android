package com.dam.t07p01.modelo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.dam.t07p01.R;
import com.dam.t07p01.vista.fragmentos.LoginFragment;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class Ficheros {

    //departamentos
    // Rutas Ficheros
    // Internos -> /data/data/com.dam.t07p01/files
    // Externos -> /storage/sdcard/Android/data/com.dam.t07p01/files

    // No utilizo las funciones openFileInput y openFileOutput de la documentación Android,
    // porque solo funcionan para almacenamiento interno!!
    // ya que solo piden el nombre del fichero sin ruta y esto falla para almacenamiento externo!!

    public static void recuperarDatosDepartamentos(Context context, List<Departamento> tDptos) throws Exception {

        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
        String nombreFichero = pref.getString(context.getResources().getString(R.string.ficheroDpto_key), "");
        String tipoFichero = pref.getString(context.getResources().getString(R.string.tipoFichero_key), "");

        if (tipoFichero.equals(context.getResources().getString(R.string.tipoFichero_Interno))) {
            nombreFichero = context.getFilesDir() + "/" + nombreFichero;
        } else if (tipoFichero.equals(context.getResources().getString(R.string.tipoFichero_Externo))) {
            String estadoSD = Environment.getExternalStorageState();
            if (!estadoSD.equals(Environment.MEDIA_MOUNTED))
                throw new Exception(context.getResources().getString(R.string.msg_ErrorRecuperarDepartamentos));
            nombreFichero = context.getExternalFilesDir(null) + "/" + nombreFichero;
        }

        try (FileInputStream fis = new FileInputStream(nombreFichero);
             DataInputStream dis = new DataInputStream(fis);) {
            while (true) {
                Departamento d = new Departamento();
                d.setId(dis.readInt());
                d.setNombre(dis.readUTF());
                d.setClave(dis.readUTF());
                tDptos.add(d);
            }
        } catch (EOFException e) {
            ;
        } catch (FileNotFoundException e) {
            // Primera ejecución!!
            Departamento dpto = new Departamento();
            dpto.setId(0);
            dpto.setNombre("admin");
            dpto.setClave("a");
            tDptos.add(dpto);
            Ficheros.guardarDatosDepartamentos(context, tDptos);
        } catch (IOException e) {
            throw new Exception(context.getResources().getString(R.string.msg_ErrorRecuperarDepartamentos), e);
        }
    }

    public static void guardarDatosDepartamentos(Context context, List<Departamento> tDptos) throws Exception {

        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
        String nombreFichero = pref.getString(context.getResources().getString(R.string.ficheroDpto_key), "");
        String tipoFichero = pref.getString(context.getResources().getString(R.string.tipoFichero_key), "");

        if (tipoFichero.equals(context.getResources().getString(R.string.tipoFichero_Interno))) {
            nombreFichero = context.getFilesDir() + "/" + nombreFichero;
        } else if (tipoFichero.equals(context.getResources().getString(R.string.tipoFichero_Externo))) {
            String estadoSD = Environment.getExternalStorageState();
            if (!estadoSD.equals(Environment.MEDIA_MOUNTED))
                throw new Exception(context.getResources().getString(R.string.msg_ErrorGuardarDepartamentos));
            nombreFichero = context.getExternalFilesDir(null) + "/" + nombreFichero;
        }

        try (FileOutputStream fos = new FileOutputStream(nombreFichero, false);
             DataOutputStream dos = new DataOutputStream(fos);) {
            for (Departamento d : tDptos) {
                dos.writeInt(d.getId());
                dos.writeUTF(d.getNombre());
                dos.writeUTF(d.getClave());
            }
        } catch (IOException e) {
            throw new Exception(context.getResources().getString(R.string.msg_ErrorGuardarDepartamentos), e);
        }
    }

    //incidencias

    public static void recuperarDatosIncidencias(Context context, List<Incidencia> tIncs) throws Exception {

        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
        String nombreFichero = pref.getString(context.getResources().getString(R.string.ficheroInc_key), "");
        String tipoFichero = pref.getString(context.getResources().getString(R.string.tipoFichero_key), "");

        if (tipoFichero.equals(context.getResources().getString(R.string.tipoFichero_Interno))) {
            nombreFichero = context.getFilesDir() + "/" + nombreFichero;
        } else if (tipoFichero.equals(context.getResources().getString(R.string.tipoFichero_Externo))) {
            String estadoSD = Environment.getExternalStorageState();
            if (!estadoSD.equals(Environment.MEDIA_MOUNTED))
                throw new Exception(context.getResources().getString(R.string.msg_ErrorRecuperarIncidencias));
            nombreFichero = context.getExternalFilesDir(null) + "/" + nombreFichero;
        }

        try (FileInputStream fis = new FileInputStream(nombreFichero);
             DataInputStream dis = new DataInputStream(fis);) {
            while (true) {
                Incidencia i = new Incidencia();
                    i.setIdDpto(dis.readInt());
                    i.setId(dis.readUTF());
                    i.setFecha(dis.readUTF());
                    i.setDescripcion(dis.readUTF());
                    i.setTipo(Incidencia.TIPO.valueOf(dis.readUTF()));
                    i.setEstado(dis.readBoolean());
                    i.setResolucion(dis.readUTF());
                tIncs.add(i);
            }
        } catch (EOFException e) {
            ;
        } catch (FileNotFoundException e) {

        } catch (IOException e) {
            throw new Exception(context.getResources().getString(R.string.msg_ErrorRecuperarIncidencias), e);
        }
    }

    public static void guardarDatosIncidencias(Context context, List<Incidencia> tIncs) throws Exception {

        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(context);
        String nombreFichero = pref.getString(context.getResources().getString(R.string.ficheroInc_key), "");
        String tipoFichero = pref.getString(context.getResources().getString(R.string.tipoFichero_key), "");

        if (tipoFichero.equals(context.getResources().getString(R.string.tipoFichero_Interno))) {
            nombreFichero = context.getFilesDir() + "/" + nombreFichero;
        } else if (tipoFichero.equals(context.getResources().getString(R.string.tipoFichero_Externo))) {
            String estadoSD = Environment.getExternalStorageState();
            if (!estadoSD.equals(Environment.MEDIA_MOUNTED))
                throw new Exception(context.getResources().getString(R.string.msg_ErrorGuardarIncidencias));
            nombreFichero = context.getExternalFilesDir(null) + "/" + nombreFichero;
        }

        try (FileOutputStream fos = new FileOutputStream(nombreFichero, false);
             DataOutputStream dos = new DataOutputStream(fos);) {
            for (Incidencia i : tIncs) {
                dos.writeInt(i.getIdDpto());
                dos.writeUTF(i.getId());
                dos.writeUTF(i.getFecha());
                dos.writeUTF(i.getDescripcion());
                dos.writeUTF(i.getTipo().name());
                dos.writeByte((i.isEstado() ? 1 : 0));
                dos.writeUTF(i.getResolucion());
            }
        } catch (IOException e) {
            throw new Exception(context.getResources().getString(R.string.msg_ErrorGuardarIncidencias), e);
        }
    }
}
