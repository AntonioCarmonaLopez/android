package com.dam.t07p01.vistamodelo;

import android.app.Application;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.dam.t07p01.modelo.Departamento;

import java.util.List;

import static com.dam.t07p01.vistamodelo.IncLogica.bajaIncidenciaXDpto;
import static com.dam.t07p01.vistamodelo.IncLogica.recuperarDatosIncidencias;

public class DptsViewModel extends AndroidViewModel {

    /* ViewModel Dptos ****************************************************************************/

    private MutableLiveData<List<Departamento>> mDptos;
    private Context mContext;

    public DptsViewModel(@NonNull Application application) {
        super(application);
        mDptos = new MutableLiveData<>();
        mContext = application;
    }

    public LiveData<List<Departamento>> getDptos() {
        mDptos.setValue(DptoLogica.recuperaDptos());
        return mDptos;
    }

    public List<Departamento> getDptosNoLive() {
        return DptoLogica.recuperaDptos();
    }

    public boolean altaDepartamento(Departamento dpto) {
        if (DptoLogica.altaIncidencia(dpto)) {
            mDptos.setValue(DptoLogica.recuperaDptos());
            return true;
        } else {
            return false;
        }
    }

    public boolean editarDepartamento(Departamento dpto) {
        if (DptoLogica.editarDepartamento(dpto)) {
            mDptos.setValue(DptoLogica.recuperaDptos());
            return true;
        } else {
            return false;
        }
    }

    public boolean bajaDepartamento(Departamento dpto) {
        if (DptoLogica.bajaDepartamento(dpto)) {
            mDptos.setValue(DptoLogica.recuperaDptos());
            recuperarDatosIncidencias(mContext,dpto);
            bajaIncidenciaXDpto(dpto);
            return true;
        } else {
            return false;
        }
    }

    public boolean recuperarDatosDepartamentos() {
        return DptoLogica.recuperarDatosDepartamentos(mContext);
    }

    public boolean guardarDatosDepartamentos() {
        return DptoLogica.guardarDatosDepartamentos(mContext);
    }

}
