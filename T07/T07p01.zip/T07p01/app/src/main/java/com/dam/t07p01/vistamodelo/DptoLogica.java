package com.dam.t07p01.vistamodelo;

import android.content.Context;

import com.dam.t07p01.modelo.Datos;
import com.dam.t07p01.modelo.Departamento;
import com.dam.t07p01.modelo.Ficheros;

import java.util.List;

import static com.dam.t07p01.vistamodelo.IncLogica.recuperarDatosIncidencias;

public class DptoLogica {


    /* Métodos Lógica Dptos ***********************************************************************/

    public static List<Departamento> recuperaDptos() {
        return Datos.getInstance().getDptos();
    }

    public static boolean existeDepartamento(Departamento dpto) {
        for (Departamento d : Datos.getInstance().getDptos())
            if (d.getId() == dpto.getId())
                return true;
        return false;
    }

    public static boolean altaIncidencia(Departamento dpto) {
        if (existeDepartamento(dpto)) return false;
        return Datos.getInstance().getDptos().add(dpto);
    }

    public static boolean editarDepartamento(Departamento dpto) {
        if (!existeDepartamento(dpto)) return false;
        for (Departamento d : Datos.getInstance().getDptos())
            if (d.getId() == dpto.getId()) {
                d.setNombre(dpto.getNombre());
                d.setClave(dpto.getClave());
                break;
            }
        return true;
    }

    public static boolean bajaDepartamento(Departamento dpto) {
        if (!existeDepartamento(dpto)) return false;
        for (Departamento d : Datos.getInstance().getDptos())
            if (d.getId() == dpto.getId()) {
                Datos.getInstance().getDptos().remove(d);
                break;
            }
        return true;
    }

    public static boolean recuperarDatosDepartamentos(Context context) {
        try {
            Datos.getInstance().getDptos().clear();
            Ficheros.recuperarDatosDepartamentos(context, Datos.getInstance().getDptos());
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static boolean guardarDatosDepartamentos(Context context) {
        try {
            Ficheros.guardarDatosDepartamentos(context, Datos.getInstance().getDptos());
        } catch (Exception e) {
            return false;
        }
        return true;
    }

}
