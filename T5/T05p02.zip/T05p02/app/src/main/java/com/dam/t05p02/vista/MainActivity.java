package com.dam.t05p02.vista;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import com.dam.t05p02.R;
import com.dam.t05p02.dialogos.DlgConfirmacion;
import com.dam.t05p02.dialogos.DlgSeleccionFecha;
import com.dam.t05p02.modelo.Alumno;
import com.dam.t05p02.fragments.AltaFragment;
import com.dam.t05p02.fragments.BajaFragment;
import com.dam.t05p02.fragments.ListadoFragment;
import com.dam.t05p02.vistamodelo.Datos;
import com.dam.t05p02.vistamodelo.LogicaAlumno;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
        DlgConfirmacion.DlgConfirmacionListener {

    private DrawerLayout mDrawer;
    private NavigationView mNavigation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        //init


        // Config Navigation Drawer
        mDrawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, mDrawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawer.addDrawerListener(toggle);
        toggle.syncState();
        mNavigation = findViewById(R.id.nav_view);
        mNavigation.setNavigationItemSelectedListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mnSalir:
                confSalir();
                return true;
        }
        return super.onOptionsItemSelected(item);

    }


    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        confSalir();
    }

    private void confSalir() {
        DlgConfirmacion dc = new DlgConfirmacion();
        dc.setTitulo(R.string.alerta);
        dc.setMensaje(R.string.salir);
        dc.show(getSupportFragmentManager(), "salir");
    }


    @Override
    public void onDlgConfirmacionPositiveClick(DialogFragment dialog) {
        for (Fragment f : getSupportFragmentManager().getFragments())
            getSupportFragmentManager().beginTransaction().remove(f).commit();
        finish();
    }

    @Override
    public void onDlgConfirmacionNegativeClick(DialogFragment dialog) {

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Intent i;
        switch (menuItem.getItemId()) {
            case R.id.nav_alta:
                i = new Intent(this, AltaActivity.class);
                startActivity(i);
                break;
            case R.id.nav_listado:
                if(Datos.getInstance().gettAlumnos().size()<1){
                    Toast.makeText(this,getString(R.string.vacia),Toast.LENGTH_SHORT).show();
                    return false;
                }
                i = new Intent(this,ListadoActivity.class);
                startActivity(i);
                break;
            case R.id.nav_baja:
                i = new Intent(this,BajaActivity.class);
                startActivity(i);
                break;
        }
        return true;
    }
}
