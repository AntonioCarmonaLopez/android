package com.dam.t05p02.fragments;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.dam.t05p02.R;
import com.dam.t05p02.adaptadores.AdaptadorAlumnosRv;
import com.dam.t05p02.modelo.Alumno;
import com.dam.t05p02.vistamodelo.Datos;
import com.dam.t05p02.vistamodelo.LogicaAlumno;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;

public class ListadoFragment extends Fragment {

    private RecyclerView rvAlumnos;
    private AdaptadorAlumnosRv mAdaptadorAlumnos;
    private OnFragmentListadoListener mListenerListado;
    private BottomNavigationView btNavigation;
    private Bitmap bitmapimage;
    private ImageView ivFoto;

    public interface OnFragmentListadoListener{
        void onFragmentListado(int pos,String id);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentListadoListener) {
            mListenerListado = (OnFragmentListadoListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_listado, container, false);
        //findViewById
        rvAlumnos = root.findViewById(R.id.rvAlumnos);
        btNavigation = root.findViewById(R.id.btNavigation);
        ivFoto = root.findViewById(R.id.ivFoto);
        //init
        rvAlumnos.setHasFixedSize(true);
        rvAlumnos.setLayoutManager(new LinearLayoutManager(getContext()));

        rvAlumnos.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL));
        mAdaptadorAlumnos = new AdaptadorAlumnosRv(Datos.getInstance().gettAlumnos());
        rvAlumnos.setAdapter(mAdaptadorAlumnos);

        //listener
        btNavigation.setOnNavigationItemSelectedListener(bt_selected);
        if(getArguments()!=null)
             bitmapimage = getArguments().getParcelable("imagen");
        if (bitmapimage != null)
            ivFoto.setImageBitmap(bitmapimage);

        return root;
    }

    private BottomNavigationView.OnNavigationItemSelectedListener bt_selected=new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            int pos=mAdaptadorAlumnos.getItemPos();
            if(pos<0){
                Snackbar.make(getActivity().findViewById(android.R.id.content),getString(R.string.must_choose),Snackbar.LENGTH_SHORT).show();
                return false;
            }
            switch (menuItem.getItemId()) {
                case R.id.bnEdit:
                    mListenerListado.onFragmentListado(pos, "edit");
                    break;
                case R.id.bnDelete:
                    mListenerListado.onFragmentListado(pos,"delete");
            break;
                case R.id.bnPhoto:
                    mListenerListado.onFragmentListado(pos,"photo");
                    break;
            }
            mAdaptadorAlumnos.notifyItemChanged(pos);
            return true;
        }
    };

    @Override
    public void onDetach() {
        super.onDetach();
    }
}