package com.dam.t05p02.vista;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.dam.t05p02.R;
import com.dam.t05p02.dialogos.DlgSeleccionFecha;
import com.dam.t05p02.fragments.AltaFragment;
import com.dam.t05p02.modelo.Alumno;
import com.dam.t05p02.vistamodelo.LogicaAlumno;
import com.google.android.material.snackbar.Snackbar;

public class AltaActivity extends AppCompatActivity
        implements AltaFragment.OnFragmentAltaListener,
                    DlgSeleccionFecha.DlgSeleccionFechaListener{

    public static final String TAG_ALTA = "Frag. Alta";
    public static final String TAG_EDITAR = "Frag. Editar";
    private Alumno alumno;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alta);

        alumno = getIntent().getParcelableExtra("student");
        if (alumno != null) {
            AltaFragment altaFragment = new AltaFragment();
            Bundle b = new Bundle();
            b.putParcelable("student", alumno);
            altaFragment.setArguments(b);
            setTitle(getString(R.string.editar));
            getSupportFragmentManager().beginTransaction().replace(R.id.altaContainer, altaFragment, TAG_EDITAR).commit();
            return;
        }
        setTitle(getString(R.string.alta));
        getSupportFragmentManager().beginTransaction().replace(R.id.altaContainer, new AltaFragment(), TAG_ALTA).commit();
    }

    @Override
    public void onFragmentAltaAceptar(String op, Alumno alumno) {

        switch (op) {
            case "alta":
                if (LogicaAlumno.altaAlumno(alumno)) {
                    Toast.makeText(getApplicationContext(), getString(R.string.alta_ok), Toast.LENGTH_SHORT).show();
                    finish();
                }
                Toast.makeText(getApplicationContext(), getString(R.string.alta_ko), Toast.LENGTH_SHORT).show();
                finish();
                return;
            case "editar":
                if (LogicaAlumno.editarAlumno(alumno)) {
                    Toast.makeText(getApplicationContext(), getString(R.string.edit_ok), Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                Toast.makeText(getApplicationContext(), getString(R.string.edit_ko), Toast.LENGTH_SHORT).show();
                finish();
        }
    }

    @Override
    public void onFragmentAltaCancelar() {
        finish();
    }


    @Override
    public void onFragmentAltaFecha(Alumno alumno) {
        this.alumno=alumno;
        DlgSeleccionFecha df = new DlgSeleccionFecha();
        df.show(getSupportFragmentManager(), "fecha");

    }

    @Override
    public void onDlgSeleccionFechaClick(DialogFragment dialog, int year, int month, int day) {
        StringBuilder fecha=new StringBuilder();
        fecha.append(day).append("/").append(month).append("/").append(year);
        alumno.setFecNac(fecha.toString());
        AltaFragment altaFragment=new AltaFragment();
        Bundle b=new Bundle();
        b.putString("fecha",fecha.toString());
        b.putParcelable("student",alumno);
        altaFragment.setArguments(b);
        getSupportFragmentManager().beginTransaction().replace(R.id.altaContainer,altaFragment,TAG_ALTA).commit();

    }
}
