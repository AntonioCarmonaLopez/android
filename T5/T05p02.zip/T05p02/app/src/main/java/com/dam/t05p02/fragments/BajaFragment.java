package com.dam.t05p02.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.dam.t05p02.R;
import com.dam.t05p02.dialogos.DlgAlerta;
import com.dam.t05p02.modelo.Alumno;

public class BajaFragment extends Fragment {

    private EditText etDni;
    private Button btAceptar,btCancelar;
    private OnBajaFragmentListener mListener;

    public  interface OnBajaFragmentListener{
        void onFragmentBajaAceptar(String dni);
        void onFragmentBajaCancelar();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnBajaFragmentListener) {
            mListener = (OnBajaFragmentListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_baja, container, false);
        //find
        etDni = root.findViewById(R.id.etDni);
        btAceptar=root.findViewById(R.id.btAceptar);
        btCancelar=root.findViewById(R.id.btCancelar);

        //listener
        btAceptar.setOnClickListener(bt_click);
        btCancelar.setOnClickListener(bt_click);

        return root;
    }

    private View.OnClickListener bt_click=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btAceptar:
                    if(!check())
                        return;
                    mListener.onFragmentBajaAceptar(etDni.getText().toString());
                    return;
                case R.id.btCancelar:
                    mListener.onFragmentBajaCancelar();
                    return;

            }
        }
    };

    private boolean check() {
        if (etDni.getText().toString().equals("")) {
            DlgAlerta da = new DlgAlerta();
            da.setTitulo(R.string.alerta);
            da.setMensaje(R.string.obligatorios);
            da.show(getFragmentManager(), "alerta");
            return false;
        }
        return true;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener=null;
    }
}