package com.dam.t05p02.vista;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Toast;

import com.dam.t05p02.R;
import com.dam.t05p02.dialogos.DlgConfirmacion;
import com.dam.t05p02.dialogos.DlgSeleccionFecha;
import com.dam.t05p02.fragments.AltaFragment;
import com.dam.t05p02.fragments.ListadoFragment;
import com.dam.t05p02.modelo.Alumno;
import com.dam.t05p02.vistamodelo.Datos;
import com.dam.t05p02.vistamodelo.LogicaAlumno;
import com.google.android.material.snackbar.Snackbar;

public class ListadoActivity extends AppCompatActivity
        implements ListadoFragment.OnFragmentListadoListener,
                    DlgConfirmacion.DlgConfirmacionListener{

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private int pos;

    private static final String TAG_LISTADO = "Frag. Listado";
    private Alumno alumno;
    private ListadoFragment listadoFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado);
        setTitle(getString(R.string.listado));
        listadoFragment = new ListadoFragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.listadoContainer, listadoFragment, TAG_LISTADO).commit();
    }


    @Override
    public void onFragmentListado(int pos, String id) {
        this.pos = pos;
        alumno = Datos.getInstance().gettAlumnos().get(pos);
        switch (id.toLowerCase()) {
            case "edit":
                Intent i = new Intent(this, AltaActivity.class);
                i.putExtra("student", alumno);
                startActivity(i);
                break;
            case "delete":
                confBorrar();
                break;
            case "photo":
                tomarFoto();
                break;
        }

    }

    public void tomarFoto() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            alumno.setImagen(imageBitmap);
            listadoFragment = new ListadoFragment();
            Bundle b = new Bundle();
            b.putParcelable("imagen", imageBitmap);
            listadoFragment.setArguments(b);
            getSupportFragmentManager().beginTransaction().replace(R.id.listadoContainer, listadoFragment, TAG_LISTADO).commit();
        }
    }

    private void confBorrar() {

       DlgConfirmacion dc=new DlgConfirmacion();
       dc.setTitulo(R.string.alerta);
       dc.setMensaje(R.string.conf_borrar);
       dc.show(getSupportFragmentManager(),"conf. Borrar");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onDlgConfirmacionPositiveClick(DialogFragment dialog) {
        if (LogicaAlumno.bajaAlumno(alumno))
            Toast.makeText(getApplicationContext(), getString(R.string.baja_ok), Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(getApplicationContext(), getString(R.string.baja_ko), Toast.LENGTH_SHORT).show();
        getSupportFragmentManager().beginTransaction().replace(R.id.listadoContainer, new ListadoFragment(), TAG_LISTADO).commit();
    }

    @Override
    public void onDlgConfirmacionNegativeClick(DialogFragment dialog) {

    }
}
