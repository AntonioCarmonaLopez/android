package com.dam.t05p02.fragments;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.dam.t05p02.R;
import com.dam.t05p02.dialogos.DlgAlerta;
import com.dam.t05p02.modelo.Alumno;
import com.dam.t05p02.vista.AltaActivity;

public class AltaFragment extends Fragment {

    private EditText etDni, etNombre, etFecNac;
    private Spinner spCiclo;
    private Button btAceptar, btCancelar, btFecha;
    private OnFragmentAltaListener mListener;
    private String fecha;


    public interface OnFragmentAltaListener {

        void onFragmentAltaAceptar(String op,Alumno alumno);

        void onFragmentAltaCancelar();

        void onFragmentAltaFecha(Alumno alumno);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentAltaListener) {
            mListener = (OnFragmentAltaListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_alta, container, false);

        //findViewById
        etDni = root.findViewById(R.id.etDni);
        etNombre = root.findViewById(R.id.etNombre);
        etFecNac = root.findViewById(R.id.etFecNac);
        spCiclo = root.findViewById(R.id.spCiclo);
        btAceptar = root.findViewById(R.id.btAceptar);
        btCancelar = root.findViewById(R.id.btCancelar);
        btFecha = root.findViewById(R.id.btChoice);

        //init
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.ciclos, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spCiclo.setAdapter(adapter);
        etFecNac.setEnabled(false);


        if (getArguments() != null) {
            fecha = getArguments().getString("fecha");
            Alumno a = getArguments().getParcelable("student");
            if (a != null) {
                etDni.setText(a.getDni());
                etDni.setEnabled(false);
                etNombre.setText(a.getNombre());
                etFecNac.setText(a.getFecNac());
                String ciclo = a.getCiclo();
                if (ciclo.equals("DAM"))
                    spCiclo.setSelection(0);
                else
                    spCiclo.setSelection(1);
            }
            if (fecha != null)
                etFecNac.setText(fecha);
        }

        //listener
        btFecha.setOnClickListener(btClick);
        btAceptar.setOnClickListener(btClick);
        btCancelar.setOnClickListener(btClick);
        return root;
    }

    private View.OnClickListener btClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Alumno a;
            String op;
            switch (v.getId()) {
                case R.id.btAceptar:
                    if (!check())
                        return;
                    a = new Alumno();
                    a.setNombre(etNombre.getText().toString());
                    a.setDni(etDni.getText().toString());
                    a.setFecNac(etFecNac.getText().toString());
                    a.setCiclo(spCiclo.getSelectedItem().toString());
                    if (AltaFragment.this.getTag().equals(AltaActivity.TAG_ALTA))
                        op="alta";
                    else
                        op="editar";
                    mListener.onFragmentAltaAceptar(op,a);
                    return;
                case R.id.btCancelar:
                    mListener.onFragmentAltaCancelar();
                    break;
                case R.id.btChoice:
                    a = new Alumno();
                    a.setNombre(etNombre.getText().toString());
                    a.setDni(etDni.getText().toString());
                    a.setFecNac(etFecNac.getText().toString());
                    a.setCiclo(spCiclo.getSelectedItem().toString());
                    mListener.onFragmentAltaFecha(a);
                    break;
            }
        }
    };

    private boolean check() {
        if (etDni.getText().toString().equals("") || etNombre.getText().equals("")) {
            DlgAlerta da = new DlgAlerta();
            da.setTitulo(R.string.alerta);
            da.setMensaje(R.string.obligatorios);
            da.show(getFragmentManager(), "alerta");
            return false;
        }
        return true;
    }


    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
}