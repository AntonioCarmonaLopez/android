package com.dam.t05p02.vista;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.dam.t05p02.R;
import com.dam.t05p02.fragments.BajaFragment;
import com.dam.t05p02.modelo.Alumno;
import com.dam.t05p02.vistamodelo.LogicaAlumno;
import com.google.android.material.snackbar.Snackbar;

public class BajaActivity extends AppCompatActivity
                        implements BajaFragment.OnBajaFragmentListener{

    private static final String TAG_BAJA="Tag. Baja";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(getString(R.string.baja));
        setContentView(R.layout.activity_baja);
        getSupportFragmentManager().beginTransaction().replace(R.id.bajaContainer,new BajaFragment(),TAG_BAJA).commit();
    }

    @Override
    public void onFragmentBajaAceptar(String dni) {
        Alumno a = new Alumno();
        a.setDni(dni);
        if (LogicaAlumno.bajaAlumno(a)) {
            Snackbar.make(findViewById(android.R.id.content), getString(R.string.baja_ok), Snackbar.LENGTH_SHORT).show();
            finish();
            return;
        }
        Snackbar.make(findViewById(android.R.id.content), getString(R.string.baja_ko), Snackbar.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public void onFragmentBajaCancelar() {
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
