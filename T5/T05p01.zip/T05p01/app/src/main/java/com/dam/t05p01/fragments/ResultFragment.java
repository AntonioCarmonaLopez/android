package com.dam.t05p01.fragments;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.dam.t05p01.R;
import com.dam.t05p01.vista.MainActivity;
import com.dam.t05p01.vista.Resultado;

public class ResultFragment extends Fragment {

    private TextView txRes;
    private Button btVolver;
    private double resultado;


    private OnFragmentResultInteractionListener mListener;

    public interface OnFragmentResultInteractionListener {
        void onVolver(String op, double resultado);
        void onVolverLand(double resultado);
    }

    public ResultFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentResultInteractionListener) {
            mListener = (OnFragmentResultInteractionListener) context;

        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentResultInteractionListener");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //receiving data from activity
        if(getArguments()!=null)
            resultado = getArguments().getDouble("res");
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_result, container, false);
        //findbyid
        txRes = v.findViewById(R.id.txResultado);
        btVolver = v.findViewById(R.id.btVolver);
        //init
        txRes.setText(String.valueOf(resultado));
        //listener
        btVolver.setOnClickListener(volver_OnClickListener);
        return v;
    }

    public void setResultado(double resultado){
        txRes.setText(String.valueOf(resultado));
    }
    //send data to activity
    private View.OnClickListener volver_OnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            txRes.setText("");
            mListener.onVolver("volver",resultado);
            mListener.onVolverLand(resultado);
        }
    };


    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


}
