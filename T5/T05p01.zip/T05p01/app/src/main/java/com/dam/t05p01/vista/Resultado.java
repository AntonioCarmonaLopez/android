package com.dam.t05p01.vista;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.app.FragmentManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.dam.t05p01.R;
import com.dam.t05p01.fragments.ResultFragment;

public class Resultado extends AppCompatActivity
        implements ResultFragment.OnFragmentResultInteractionListener {


    private double resultado;
    private ResultFragment mResultFragment;
    private Bundle bundle;
    private Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);
        //coger datos from mainActivity && send to fragmentActivity
        bundle = getIntent().getExtras();
        resultado= bundle.getDouble("resultado");

        sendData(resultado);



    }

    private void sendData(double resultado) {
        //send data to fragment
        Bundle bundle = new Bundle();
        bundle.putDouble("res", resultado);
        ResultFragment myFragment = new ResultFragment();
        myFragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_result,myFragment).commit();
    }

    @Override
    public void onVolver(String op,double resultado) {
        intent = new Intent();
        switch (op){
            case "volver":
                intent.putExtra("res",resultado);
                setResult(Resultado.RESULT_OK, intent);
                break;
                default:
                    setResult(RESULT_CANCELED);
        }

        finish();

    }

    @Override
    public void onVolverLand(double resultado) {

    }
}
