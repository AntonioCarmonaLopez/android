package com.dam.t05p01.vista;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.dam.t05p01.R;
import com.dam.t05p01.fragments.MainFragment;
import com.dam.t05p01.fragments.ResultFragment;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity
        implements MainFragment.OnFragmentMainInteractionListener,ResultFragment.OnFragmentResultInteractionListener {


    private final int ID_APP = 1;
    private double resultado;
    private Intent intent;
    private MainFragment mFragmentMain;
    private ResultFragment mFragmentResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // FindViewByIds
        mFragmentMain = (MainFragment) getSupportFragmentManager().findFragmentById(R.id.fragment);
        mFragmentResult = (ResultFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_result);
        //init
        //mFragmentResult=new ResultFragment();

    }


    private boolean check(String num1, String num2) {
        if (num1.equals("") && num1.trim().isEmpty() || num2.equals("") && num2.trim().isEmpty() ) {
            Toast.makeText(this, getResources().getText(R.string.obligatorios), Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    @Override
    public void onOperacion(String op, String num1, String num2) {

        if (check(num1, num2)) {
            switch (op) {
                case "+":
                    resultado = Double.parseDouble(num1) + Double.parseDouble(num2);
                    break;
                case "-":
                    resultado = Double.parseDouble(num1) - Double.parseDouble(num2);
                    break;
                case "*":
                    resultado = Double.parseDouble(num1) * Double.parseDouble(num2);
                    break;
                case "/":
                    resultado = Double.parseDouble(num1) / Double.parseDouble(num2);
                    break;
            }            boolean dualPane = mFragmentResult != null && mFragmentResult.isVisible();
            if(dualPane){
                sendData(resultado);
                return;
            }
            intent=new Intent(this,Resultado.class);
            intent.putExtra("resultado",resultado);
            startActivityForResult(intent,ID_APP);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (ID_APP){
            case RESULT_OK:
                resultado=data.getExtras().getDouble("res");
                snackbar("El resultado es: "+resultado);
                break;
            case RESULT_CANCELED:
                snackbar("Operación cancelada");

        }

    }

    private void snackbar(String msg){
        Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG).show();
    }

    private void sendData(double resultado) {
        //send data to fragment
        mFragmentResult.setResultado(resultado);
    }

    @Override
    public void onVolver(String op, double resultado) {

    }

    @Override
    public void onVolverLand(double resultado) {
        snackbar("El resultado es "+resultado);

    }
}
