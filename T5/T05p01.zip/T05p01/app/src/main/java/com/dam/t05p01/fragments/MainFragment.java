package com.dam.t05p01.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.dam.t05p01.R;

public class MainFragment extends Fragment {

    private OnFragmentMainInteractionListener mListener;
    private EditText et1, et2;
    private Button btSumar, btRestar, btMultiplicar, btDividir, btLimpiar, btCerrar;

    public MainFragment() {
        // Required empty public constructor
    }


    public interface OnFragmentMainInteractionListener {
        void onOperacion(String op, String num1, String num2);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentMainInteractionListener) {
            mListener = (OnFragmentMainInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentMainInteractionListener");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_main, container, false);
        //findViewById
        et1 = v.findViewById(R.id.etNum1);
        et2 = v.findViewById(R.id.etNum2);
        btSumar = v.findViewById(R.id.btSuma);
        btRestar = v.findViewById(R.id.btResta);
        btMultiplicar = v.findViewById(R.id.btmulti);
        btDividir = v.findViewById(R.id.btDiv);
        btLimpiar = v.findViewById(R.id.btLimpiar);
        btCerrar = v.findViewById(R.id.btCerrar);
        //listener
        btSumar.setOnClickListener(operaciones_OnClickListener);
        btRestar.setOnClickListener(operaciones_OnClickListener);
        btMultiplicar.setOnClickListener(operaciones_OnClickListener);
        btDividir.setOnClickListener(operaciones_OnClickListener);
        btLimpiar.setOnClickListener(operaciones_OnClickListener);
        btCerrar.setOnClickListener(operaciones_OnClickListener);
        return v;
    }

    private View.OnClickListener operaciones_OnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btSuma:
                    mListener.onOperacion("+", et1.getText().toString(), et2.getText().toString());
                    et1.setText("");
                    et2.setText("");
                    break;
                case R.id.btResta:
                    mListener.onOperacion("-", et1.getText().toString(), et2.getText().toString());
                    et1.setText("");
                    et2.setText("");
                    break;
                case R.id.btmulti:
                    mListener.onOperacion("*", et1.getText().toString(), et2.getText().toString());
                    et1.setText("");
                    et2.setText("");
                    break;
                case R.id.btDiv:
                    mListener.onOperacion("/", et1.getText().toString(), et2.getText().toString());
                    et1.setText("");
                    et2.setText("");
                    break;
                case R.id.btLimpiar:
                    et1.setText("");
                    et2.setText("");
                    break;
                case R.id.btCerrar:
                    getActivity().finish();
                    break;
            }
        }
    };

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

}
